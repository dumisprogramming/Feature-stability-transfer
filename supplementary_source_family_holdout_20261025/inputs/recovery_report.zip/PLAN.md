Post hoc input recovery plan recorded before this raw scan.
Recover Attack and FLOW_START_MILLISECONDS only for the union of saved source and candidate row IDs.
Check every recovered binary label against every saved input label; check complete CSV row count and archive member/size against the candidate manifest.
Count full raw binary labels, exact family strings and UTC-aligned 3/6/12/24-hour blocks. Eligibility count uses the historical quota of at least 2,000 rows per class per block and is descriptive only.
Retain family names separately by dataset; no semantic harmonisation, model fitting, target accuracy, warning association or significance testing.
Raw observed class proportions describe these benchmark captures, not production prevalence. Counts do not construct leakage-free evaluation panels.
Row IDs follow zero-based parsed-data-row order used by the original pandas reader. Binary-label agreement and input hashes are checked, but all 49 raw feature values are not replayed.
All original model, panel, prediction and seal files are read only. New local lookup files stay in Drive; the download ZIP contains aggregates, hashes and code only.
Completed datasets may be reused only after current input hashes and saved output hashes agree. An interrupted dataset restarts from its beginning in a new attempt folder.
