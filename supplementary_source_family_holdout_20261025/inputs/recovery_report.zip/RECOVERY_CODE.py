"""Raw metadata recovery and descriptive inventory; no fitted warning or detector evaluation."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, zipfile, platform
import numpy as np
import pandas as pd

DATASETS=['NF_BoT_IoT_v3','NF_CSE_CIC_IDS2018_v3','NF_ToN_IoT_v3','NF_UNSW_NB15_v3']
WIDTHS=[3,6,12,24]

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()

def write_json(p,value):
    p=Path(p);q=p.with_suffix('.tmp')
    q.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');q.replace(p)

def read_json(p):return json.loads(Path(p).read_text())

def label_input(p,expected,role):
    actual=sha(p)
    if not expected or actual!=expected:raise ValueError(f'Missing/mismatched recorded hash: {p}')
    f=pd.read_parquet(p,columns=['row_id','Label'])
    ids=pd.to_numeric(f.row_id,errors='coerce').to_numpy(float)
    if not (np.isfinite(ids).all() and (ids>=0).all() and (ids==np.floor(ids)).all() and f.row_id.is_unique):
        raise ValueError(f'Invalid row IDs: {p}')
    if not f.Label.isin([0,1]).all():raise ValueError(f'Invalid labels: {p}')
    return f,{'role':role,'rows':len(f),'sha256':actual}

def recover_all(root,run_dir,chunk_size=250000):
    root=Path(root).resolve();run_dir=Path(run_dir).resolve()
    if not root.is_dir():raise FileNotFoundError(root)
    if run_dir.parent!=root/'supplementary_raw_metadata_recovery_20261024':
        raise ValueError('Use the separate supplementary_raw_metadata_recovery_20261024 run folder')
    run_dir.mkdir(parents=True,exist_ok=True)
    plan='''Post hoc input recovery plan recorded before this raw scan.
Recover Attack and FLOW_START_MILLISECONDS only for the union of saved source and candidate row IDs.
Check every recovered binary label against every saved input label; check complete CSV row count and archive member/size against the candidate manifest.
Count full raw binary labels, exact family strings and UTC-aligned 3/6/12/24-hour blocks. Eligibility count uses the historical quota of at least 2,000 rows per class per block and is descriptive only.
Retain family names separately by dataset; no semantic harmonisation, model fitting, target accuracy, warning association or significance testing.
Raw observed class proportions describe these benchmark captures, not production prevalence. Counts do not construct leakage-free evaluation panels.
Row IDs follow zero-based parsed-data-row order used by the original pandas reader. Binary-label agreement and input hashes are checked, but all 49 raw feature values are not replayed.
All original model, panel, prediction and seal files are read only. New local lookup files stay in Drive; the download ZIP contains aggregates, hashes and code only.
Completed datasets may be reused only after current input hashes and saved output hashes agree. An interrupted dataset restarts from its beginning in a new attempt folder.
'''
    config={'datasets':DATASETS,'width_hours':WIDTHS,'chunk_size':chunk_size,'rows_per_class_quota':2000,
            'pandas_version':pd.__version__,'numpy_version':np.__version__,
            'code_sha256':hashlib.sha256(RECOVERY_SOURCE.encode()).hexdigest(),'plan_sha256':hashlib.sha256(plan.encode()).hexdigest()}
    identity=run_dir/'run_identity.json'
    if identity.exists():
        if read_json(identity)['configuration']!=config:raise ValueError('Run configuration/code differs; use a new run folder')
    else:
        write_json(identity,{'created_utc':datetime.now(timezone.utc).isoformat(),'configuration':config})
        (run_dir/'PLAN.md').write_text(plan);(run_dir/'RECOVERY_CODE.py').write_text(RECOVERY_SOURCE)
    results=[];errors=[]
    for dataset in DATASETS:
        print('\nChecking raw recovery inputs:',dataset,flush=True)
        folder=run_dir/dataset;folder.mkdir(exist_ok=True)
        try:
            mpath=root/'Paper3_Target_Panels/candidates'/dataset/'candidate_manifest.json'
            m=read_json(mpath)
            archive=root/m['raw_zip_name']
            if archive.parent!=root or not archive.is_file():raise ValueError('Raw archive path is not an existing file in Paper 3 root')
            if archive.stat().st_size!=m['raw_zip_size_bytes']:raise ValueError('Raw archive size differs from original candidate manifest')
            inputs={'candidate_manifest':sha(mpath),'raw_archive':sha(archive)}
            roles=[]
            p=root/'Paper3_Target_Label_Vault'/dataset/'target_candidate_labels.parquet'
            f,rec=label_input(p,m.get('label_vault_sha256'),'target_candidate')
            roles.append((rec,f));inputs[str(p.relative_to(root))]=rec['sha256']
            for seed in range(2027,2032):
                base=root/'Paper3_Sanitized'/dataset/f'seed_{seed}'
                sm=read_json(base/'sanitization_manifest.json')
                inputs[str((base/'sanitization_manifest.json').relative_to(root))]=sha(base/'sanitization_manifest.json')
                for split in ['train','calibration','source_test','environment']:
                    p=base/(split+'.parquet')
                    f,rec=label_input(p,sm.get('output_files',{}).get(split,{}).get('sha256'),f'seed_{seed}/{split}')
                    roles.append((rec,f));inputs[str(p.relative_to(root))]=rec['sha256']
            joined=pd.concat([f for _,f in roles],ignore_index=True).sort_values('row_id',kind='stable')
            if (joined.groupby('row_id').Label.nunique()>1).any():raise ValueError('Saved labels conflict across roles/seeds')
            joined=joined.drop_duplicates('row_id').reset_index(drop=True)
            wanted=joined.row_id.to_numpy(np.int64)
            marker=folder/'complete.json'
            if marker.exists():
                cached=read_json(marker)
                if cached['input_hashes']!=inputs:raise ValueError('Current inputs differ from completed dataset checkpoint')
                for rel,digest in cached['output_hashes'].items():
                    if sha(folder/rel)!=digest:raise ValueError('Completed recovery output failed hash verification: '+rel)
                results.append(cached);print('REUSED verified completed dataset:',dataset,flush=True);continue
            attempt=folder/datetime.now(timezone.utc).strftime('attempt_%Y%m%d_%H%M%S_%f');attempt.mkdir()
            write_json(attempt/'input_hashes.json',inputs)
            write_json(attempt/'progress.json',{'status':'RUNNING','rows_scanned':0})
            pieces=[];counts=Counter();family_counts=Counter();temporal=Counter()
            offset=0;invalid_labels=0;invalid_timestamps=0;missing_families=0
            timestamp_min=None;timestamp_max=None
            with zipfile.ZipFile(archive) as z:
                member=m['raw_csv_member'];info=z.getinfo(member)
                with z.open(info) as stream:
                    columns=pd.read_csv(stream,nrows=0).columns.tolist()
                required=['Label','Attack','FLOW_START_MILLISECONDS']
                if not set(required).issubset(columns):raise ValueError('Raw CSV lacks required metadata columns')
                with z.open(info) as stream:
                    reader=pd.read_csv(stream,usecols=required,chunksize=chunk_size,low_memory=False,
                        dtype={'Attack':'string'},on_bad_lines='error')
                    for chunk_no,chunk in enumerate(reader,1):
                        n=len(chunk);labels=pd.to_numeric(chunk.Label,errors='coerce').to_numpy(float)
                        good_label=np.isin(labels,[0,1]);invalid_labels+=int((~good_label).sum())
                        label_names=np.where(labels==0,'0',np.where(labels==1,'1','INVALID'))
                        fam=chunk.Attack
                        missing_families+=int((fam.isna()|fam.fillna('').str.strip().eq('')).sum())
                        # Missing is a separate flag/category, not a replacement family name.
                        family_frame=pd.DataFrame({'label':label_names,'family':fam.fillna(''),'family_missing':fam.isna()})
                        for (label,family,missing),v in family_frame.groupby(['label','family','family_missing'],dropna=False).size().items():
                            family_counts[(str(label),str(family),bool(missing))]+=int(v)
                        counts.update({str(k):int(v) for k,v in pd.Series(label_names).value_counts().items()})
                        timestamps=pd.to_numeric(chunk.FLOW_START_MILLISECONDS,errors='coerce').to_numpy(float)
                        good_ts=np.isfinite(timestamps)&(timestamps>=0)&(timestamps<9e18)&(timestamps==np.floor(timestamps))
                        invalid_timestamps+=int((~good_ts).sum())
                        if good_ts.any():
                            lo=int(timestamps[good_ts].min());hi=int(timestamps[good_ts].max())
                            timestamp_min=lo if timestamp_min is None else min(timestamp_min,lo)
                            timestamp_max=hi if timestamp_max is None else max(timestamp_max,hi)
                        mask=good_ts&good_label
                        valid_ts=timestamps[mask].astype(np.int64);valid_lab=labels[mask].astype(int)
                        for hours in WIDTHS:
                            width=hours*3600000
                            tmp=pd.DataFrame({'start':valid_ts//width*width,'label':valid_lab})
                            for (start,label),v in tmp.groupby(['start','label']).size().items():
                                temporal[(hours,int(start),int(label))]+=int(v)
                        left=np.searchsorted(wanted,offset);right=np.searchsorted(wanted,offset+n)
                        if right>left:
                            chosen=wanted[left:right];loc=chosen-offset
                            recovered=chunk.iloc[loc][required].copy()
                            recovered.insert(0,'row_id',chosen)
                            recovered['Label']=labels[loc]
                            recovered['FLOW_START_MILLISECONDS']=timestamps[loc]
                            recovered['timestamp_valid']=good_ts[loc]
                            pieces.append(recovered)
                        offset+=n
                        write_json(attempt/'progress.json',{'status':'RUNNING','rows_scanned':offset,'chunks_scanned':chunk_no,
                            'selected_rows_recovered':sum(len(x) for x in pieces)})
                        if chunk_no%10==0:print(dataset,format(offset,','),'raw rows scanned',flush=True)
            if offset!=int(m['rows_scanned']):raise ValueError(f'Raw row count {offset} differs from original {m["rows_scanned"]}')
            if invalid_labels!=int(m['invalid_labels']):raise ValueError('Invalid raw label count differs from original candidate scan')
            recovered=pd.concat(pieces,ignore_index=True).sort_values('row_id') if pieces else pd.DataFrame()
            if len(recovered)!=len(wanted) or not np.array_equal(recovered.row_id.to_numpy(),wanted):
                raise ValueError('Not every saved row ID was recovered exactly once')
            if not np.array_equal(recovered.Label.to_numpy(float),joined.Label.to_numpy(float)):
                raise ValueError('Recovered raw binary labels disagree with saved input labels')
            recovered['Label']=recovered.Label.astype('int8')
            recovered.to_parquet(attempt/'saved_row_metadata.parquet',index=False)
            lookup=recovered.set_index('row_id',verify_integrity=True)
            role_counts=[]
            for rec,f in roles:
                sub=lookup.loc[f.row_id]
                if not np.array_equal(sub.Label.to_numpy(),f.Label.to_numpy()):raise ValueError('Role-specific label alignment failed')
                temp=pd.DataFrame({'Label':sub.Label.to_numpy(),'Attack':sub.Attack.fillna('').to_numpy(),
                    'family_missing':sub.Attack.isna().to_numpy()})
                for (label,family,missing),v in temp.groupby(['Label','Attack','family_missing'],dropna=False).size().items():
                    role_counts.append({'dataset':dataset,'role':rec['role'],'label':int(label),'family':str(family),'family_missing':bool(missing),'rows':int(v)})
            pd.DataFrame(role_counts).to_csv(attempt/'saved_role_family_counts.csv',index=False)
            pd.DataFrame([{'dataset':dataset,'label':l,'family':f,'family_missing':m,'rows':v} for (l,f,m),v in sorted(family_counts.items())]).to_csv(attempt/'raw_family_counts.csv',index=False)
            tr=pd.DataFrame([{'dataset':dataset,'hours':h,'group_start_ms':t,'label':l,'rows':v} for (h,t,l),v in sorted(temporal.items())])
            tr.to_csv(attempt/'raw_temporal_counts.csv',index=False)
            coverage=[]
            for h in WIDTHS:
                q=tr[tr.hours==h].pivot(index='group_start_ms',columns='label',values='rows').fillna(0).reindex(columns=[0,1],fill_value=0)
                coverage.append({'hours':h,'observed_blocks_with_valid_binary_labels':len(q),'blocks_with_2000_each_class':int(((q[0]>=2000)&(q[1]>=2000)).sum()),
                    'counts_before_source_or_duplicate_exclusion':True})
            valid_total=counts['0']+counts['1']
            summary={'dataset':dataset,'status':'RAW_METADATA_RECOVERED','raw_rows':offset,'raw_class_counts':dict(counts),
                'observed_capture_attack_fraction_among_valid_binary_labels':counts['1']/valid_total if valid_total else None,
                'invalid_raw_labels':invalid_labels,'invalid_raw_timestamps':invalid_timestamps,
                'minimum_valid_timestamp_ms':timestamp_min,'maximum_valid_timestamp_ms':timestamp_max,
                'missing_or_blank_raw_families':missing_families,'saved_unique_rows_recovered':len(recovered),
                'saved_roles_checked':len(roles),'saved_raw_binary_labels_all_match':True,
                'saved_rows_invalid_timestamps':int((~recovered.timestamp_valid).sum()),'temporal_coverage':coverage,
                'all_49_raw_features_replayed':False,'new_detector_or_warning_experiments_completed':0,
                'raw_zip_sha256_is_new_reference_not_original_historical_seal':True,
                'meaning':'Full capture counts are benchmark descriptions, not production prevalence. Family strings remain dataset-specific. Temporal counts precede leakage exclusions.'}
            write_json(attempt/'summary.json',summary)
            write_json(attempt/'progress.json',{'status':'COMPLETED','rows_scanned':offset})
            hashes={str(p.relative_to(folder)):sha(p) for p in sorted(attempt.iterdir()) if p.is_file()}
            cached={'dataset':dataset,'input_hashes':inputs,'output_hashes':hashes,'attempt':attempt.name,'summary':summary}
            write_json(marker,cached);results.append(cached)
            print('Recovered and checked:',dataset,'| unique saved rows:',len(recovered),flush=True)
        except Exception as e:
            errors.append({'dataset':dataset,'error':str(e)})
            print('DATASET STOPPED:',dataset,str(e),flush=True)
    final={'status':'RECOVERY_COMPLETED' if len(results)==len(DATASETS) and not errors else 'INCOMPLETE_RECOVERY',
        'created_utc':datetime.now(timezone.utc).isoformat(),'datasets_completed':len(results),'datasets_expected':len(DATASETS),
        'summaries':[x['summary'] for x in results],'errors':errors,'python':platform.python_version(),
        'new_performance_results':False,'lookup_files_remain_in_drive':True}
    write_json(run_dir/'recovery_summary.json',final)
    # Small download bundle: no per-row lookup files, raw flows or model objects.
    package=run_dir/('recovery_report_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')+'.zip')
    with zipfile.ZipFile(package,'x',zipfile.ZIP_DEFLATED) as z:
        for name in ['PLAN.md','RECOVERY_CODE.py','run_identity.json','recovery_summary.json']:
            z.write(run_dir/name,name)
        for cached in results:
            folder=run_dir/cached['dataset'];z.write(folder/'complete.json',cached['dataset']+'/complete.json')
            for name in ['summary.json','raw_family_counts.csv','raw_temporal_counts.csv','saved_role_family_counts.csv','progress.json']:
                p=folder/cached['attempt']/name;z.write(p,cached['dataset']+'/'+name)
    print('\nStatus:',final['status']);print('Report ZIP:',package)
    if errors:print('Read the errors in recovery_summary.json; completed datasets will be verified and reused on retry.')
    return package
