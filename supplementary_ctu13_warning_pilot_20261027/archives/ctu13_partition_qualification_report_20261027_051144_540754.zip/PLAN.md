# CTU 13 partition qualification plan

Prepared 27 October 2026 after review of the completed CTU-13 inventory. This is a separate post hoc data-qualification stage. It does not fit a classifier, calculate permutation importance, test warning utility, measure natural production prevalence or establish independent institutions. All previous study outcomes and inventory labels are known. Leave original Drive folders unchanged.

## Fixed inputs and scope

Use the completed supplementary_ctu13_inventory_20261027/run_v1 Drive stage only. The supplied context pins its identity, 348 recorded files, 13 raw-file SHA-256 records, 209 digest-chunk completion records, inventories and the reviewed report hash. No new internet downloads occur. Missing or changed inputs block the stage rather than trigger replacement data acquisition.

Read and verify the parent per-row digest arrays against their recorded hashes, then reconstruct valid TCP/UDP known-label occurrences for all 13 scenarios. Unknown labels are never assigned benign/attack. Digest rows align to physical source rows because the reviewed inventory reports zero malformed, blank or undecodable data lines. Any deviation from this alignment requirement blocks reuse.

Source candidates were fixed by the inventory's initial minimum-window screen: 1, 2, 3, 6, 8, 9 and 13. All 13 scenarios are considered for target-test support so that source-window failure does not automatically exclude a useful target. No predictive model outcome is used in this stage.

## Global known-binary conflict exclusion

Rebuild the intersection of unique known-benign and known-attack canonical signatures across all 13 scenarios. It must reproduce the reviewed 1,008 conflicting signatures. Remove all known occurrences of these signatures from every scenario pool. Unknown occurrences are not used to certify truth or fine-family purity.

This exclusion uses labels across sources and possible targets after earlier results were known. It is explicitly a label-informed post hoc cohort restriction, not target-blind preprocessing. It conditions the evaluated population; a future study must not imply that the original pre-label confirmatory safeguards apply to this new cohort.

Within each scenario, choose the first known eligible raw occurrence of each remaining signature under original source-row order. Later matching known occurrences do not enter the pool. Retain exclusion counts and representative row indices. Multi-label unknown associations remain unresolved; this does not establish universal signature-label truth.

## Representative recovery and numeric precision

Copy each needed raw file from its existing Drive input to a temporary local cache while verifying exact byte count and full SHA-256. Recover only chosen representative records using the inventory's byte offsets. Validate row width, exact label, known class, canonical feature digest and textual-event digest against the recorded per-row inventory. Recover nominal local-clock 30-minute start-time bins; timezone remains unestablished.

Model matrix columns are float64:

1. protocol_is_tcp (TCP = 1, UDP = 0)
2. destination_port
3. duration_seconds
4. total_packets
5. total_bytes
6. source_bytes

This is the inventory's audit projection, not the original 49-predictor schema or the S16–S18 six directional features. Integer fields stay in 0–2^53−1 and ports in 0–65535. Each duration must satisfy Decimal(str(float(original_duration))) == Decimal(original_duration). Otherwise stop rather than assume a decimal signature proves float64 model-space separation. Together with fixed integer/protocol encoding, this roundtrip gate makes distinct retained canonical values distinguishable in the represented numeric matrix. No float32 conversion, imputation or scaling occurs here.

## Shared role assignment for each seed

Use seeds 2027–2031. Hash a fixed domain tag, seed and canonical signature with SHA-256; take the first eight bytes as a big-endian integer modulo 100. The same signature has the same role in EVERY capture for that seed:

- 0–29: training pool (30 percent nominal)
- 30–39: calibration pool (10 percent nominal)
- 40–49: test pool (10 percent nominal)
- 50–99: warning environment pool (50 percent nominal)

These are nominal hash bands, not guaranteed realized class fractions. This design reserves test signatures away from all fitting/calibration/warning roles across captures within a seed. Same-role repeats across captures are permitted and reported as a dependence limitation. Signatures can change roles between seeds; seeds are repeated computations, not independent capture evidence.

The test panel serves as source test when its capture supplies a model and external target test when another capture supplies the model. Do not count those reuses as independent samples. Exact textual event overlap was reported zero in the earlier inventory, but this stage's role gates use the evaluated canonical projection and precision checks, not that textual result alone.

## Fixed support thresholds and sampling

For each scenario and seed:

| Role | Minimum known rows per class | Cap per class | Selection |
|---|---:|---:|---|
| Training | 500 | 10,000 | Match both classes to min(cap, available benign, available attack) |
| Calibration | 100 | 2,000 | Same fixed balancing rule |
| Test | 100 | 2,000 | Same fixed balancing rule |
| Environment window | 100 | 100 | Retain only whole 30-minute bins supporting 100 per class |

Within each role/class or environment window/class, choose the smallest deterministic SHA-256 priorities, with domain/seed tags. Preserve a stable order in saved arrays. If a fitting/calibration/test role fails its floor, save an empty selected panel plus the available counts and fail flag; never pad, duplicate or lower quotas. The pool remains saved for inspection.

Require at least four retained warning windows for source eligibility. Actual environmental groups retain chronological 30-minute membership. Matched pseudo-groups use the identical selected environmental rows and preserve 100 rows per class per group under a deterministic class-specific hash assignment. Verify every actual/pseudo group quota.

A source is qualified for this bounded pilot screen only if it is among the seven fixed candidates AND training, calibration, test and environment gates pass in all five seeds. A target needs test support in all five seeds. List every ordered qualified source–target pair excluding self-transfer. No classifier or target performance is used to choose this list. If none survive, the audit still completes with no pilot-ready cases; thresholds are not automatically relaxed.

Four windows and these class floors establish a computational feasibility screen, not adequate statistical power, clinical/operational validity or independence. A subsequent model/warning protocol and uncertainty assessment must be reviewed and fixed separately.

## Disjointness checks

Within every scenario/seed, all four selected roles must have empty canonical-signature intersections. For each seed, union signatures across ALL 13 scenarios within each role, then check all six cross-role intersections are zero. The numeric roundtrip gate above is required before interpreting this as model-representation disjointness.

Record training constant columns without silently deleting predictors. Future rank-stability analysis must keep ties/constant-vector handling explicit. Source identity, probable malware and raw endpoint values are not predictors. Signature grouping does not eliminate common institutional, host, exporter or labelling artefacts.

## Persistence and output

New Drive folder: Paper3_DataSet/supplementary_ctu13_partition_qualification_20261027/run_v1.

Checkpoint parent validation, known-record extraction per scenario, conflict reconstruction, recovered pools per scenario, selected panels per scenario/seed, cross-role audit and final gate decision. Verify cached output hashes before reuse; changed code, context, configuration, Python or NumPy identity blocks a mixed resume. Same unchanged notebook restores completed checkpoints in a fresh local runtime. Only disposable local copies created by this new stage may be removed; original Drive inputs, digest shards and older results remain untouched.

The first qualification run reads existing digest files and raw CSVs from Drive; it does not repeat the original broad inventory or reacquire 2.73 GB from the internet. Additional Drive space is needed for smaller known-record, representative and panel arrays. Allow 1–2 GB additional Drive space and ample local runtime space; exact usage/runtime has not been measured on the complete inputs.

Complete status: CTU13_PARTITION_QUALIFICATION_COMPLETE when execution and all structural checks finish, even if support gates yield zero eligible sources. The gate_decision.json separately states whether any bounded pilot cases exist. Execution errors produce CTU13_PARTITION_QUALIFICATION_PARTIAL_RESUMABLE, with local report retained when possible. Insufficient scientific support is not disguised as an execution failure or a successful warning experiment.

Compact report ZIP contains code, plan, context pins, validation summaries, per-scenario key/pool counts, all 65 seed qualifications, cross-role summaries, gate decision, CSV summary and checksums. Known-row arrays, per-representative data and selected panel NPZs remain in Drive and are excluded. Saved-record verification cannot independently replay those omitted arrays or the original raw lines.

## Interpretation and next decision

Neris 1/2/9 is a provider-recorded same-binary candidate, not a prequalified final source list. A same-binary repeat-capture test differs from unseen-family exclusion; excluding a lone executed malware from a single-family source can remove all attack training data. General fine-family warning evaluation would need a qualified multi-family design. All CTU scenarios remain from one institution.

No result from this stage closes natural production prevalence, independent-institution generalization, semantic identity of all attacks, or general predictive warning utility. The next step after reviewing the returned qualification report is to fix a bounded model-and-warning pilot using only support-qualified cases, if any.

## Original dataset attribution

CTU-13 provider: https://www.stratosphereips.org/datasets-ctu13

Garcia S, Grill M, Stiborek J, Zunino A. An empirical comparison of botnet detection methods. Computers & Security. 2014;45:100–123. https://doi.org/10.1016/j.cose.2014.05.011

Follow the provider's attribution and data-use terms. Preparing this package does not assign a new dataset licence.
