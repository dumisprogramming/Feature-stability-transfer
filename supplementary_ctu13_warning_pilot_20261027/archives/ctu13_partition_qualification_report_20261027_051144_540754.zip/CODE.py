"""Post hoc CTU partition qualification; no network acquisition or model fitting."""
from pathlib import Path
from datetime import datetime,timezone
from decimal import Decimal
from itertools import combinations
import json,hashlib,shutil,csv,platform,time,zipfile,re
import numpy as np
STAGE='supplementary_ctu13_partition_qualification_20261027'
PARENT_DTYPE=np.dtype([('feature','S32'),('event','S32'),('label','<u2'),('cls','u1'),('valid','?')])
KNOWN_DTYPE=np.dtype([('sig','S32'),('event','S32'),('label','<u2'),('y','u1'),('row','<u4')])
COLUMNS=['StartTime','Dur','Proto','SrcAddr','Sport','Dir','DstAddr','Dport','State','sTos','dTos','TotPkts','TotBytes','SrcBytes','Label']
FEATURES=['protocol_is_tcp','destination_port','duration_seconds','total_packets','total_bytes','source_bytes']
DEFAULT={'seeds':[2027,2028,2029,2030,2031],'train_min_per_class':500,'train_cap_per_class':10000,'calibration_min_per_class':100,'calibration_cap_per_class':2000,'test_min_per_class':100,'test_cap_per_class':2000,'environment_class_quota':100,'minimum_environment_windows':4,'role_bands':[30,40,50,100],'role_names':['train','calibration','test','environment'],'synthetic_test':False}
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for data in iter(lambda:f.read(4*1024*1024),b''):h.update(data)
 return h.hexdigest()
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,allow_nan=False).encode()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n');tmp.replace(p)
def npz(path,**arrays):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('wb') as f:np.savez_compressed(f,**arrays)
def load(path):
 with np.load(path,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def bytes32(x):return np.asarray(x,dtype='S32').tobytes()
def priority(tag,seed,sig):return hashlib.sha256(f'ctu-qualification-v1|{tag}|{seed}|'.encode()+bytes32(sig)).digest()
def role_assignment(signatures,seed,config):
 v=np.array([int.from_bytes(priority('global-role',seed,s)[:8],'big')%100 for s in signatures],dtype='u1');return np.searchsorted(config['role_bands'],v,side='right').astype('u1')

class Workspace:
 def __init__(self,paper3_root,context,source,plan,local_root,config):
  self.parent=Path(paper3_root)/context['parent_stage']/'run_v1';self.remote=Path(paper3_root)/STAGE/'run_v1';self.local=Path(local_root)/STAGE/'run_v1';self.context=context;self.config=config
  if not self.parent.is_dir():raise FileNotFoundError('Completed inventory folder not found: '+str(self.parent))
  self.remote.mkdir(parents=True,exist_ok=True);self.local.mkdir(parents=True,exist_ok=True)
  self.identity={'code_sha256':hashlib.sha256(source.encode()).hexdigest(),'context_sha256':digest(context),'plan_sha256':hashlib.sha256(plan.encode()).hexdigest(),'config':config,'python':platform.python_version(),'numpy':np.__version__}
  if (self.remote/'identity.json').exists() and read(self.remote/'identity.json')!=self.identity:raise ValueError('Resume identity changed; use the same unchanged notebook and runtime')
  for n,v in [('identity.json',self.identity),('context.json',context)]:write(self.local/n,v)
  (self.local/'CODE.py').write_text(source);(self.local/'PLAN.md').write_text(plan)
  for n in ['identity.json','context.json','CODE.py','PLAN.md']:self.upload(n)
 def upload(self,rel):
  src=self.local/rel;dst=self.remote/rel;dst.parent.mkdir(parents=True,exist_ok=True);tmp=dst.with_suffix(dst.suffix+'.tmp');shutil.copyfile(src,tmp)
  if sha(tmp)!=sha(src):raise IOError('Drive copy hash differs: '+rel)
  tmp.replace(dst)
 def finish(self,marker,outputs,details):
  for n in outputs:self.upload(n)
  m={'identity':self.identity,'outputs':{n:sha(self.local/n) for n in outputs},'details':details,'details_sha256':digest(details)};write(self.local/marker,m);self.upload(marker)
 def cached(self,marker):
  path=self.remote/marker
  if not path.exists():return None
  m=read(path)
  if m['identity']!=self.identity or digest(m['details'])!=m['details_sha256']:raise ValueError('Checkpoint identity/details differ: '+marker)
  for n,h in m['outputs'].items():
   src=self.remote/n
   if sha(src)!=h:raise ValueError('Checkpoint output changed: '+n)
   dst=self.local/n;dst.parent.mkdir(parents=True,exist_ok=True)
   if not dst.exists() or sha(dst)!=h:shutil.copyfile(src,dst)
  dst=self.local/marker;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dst);return m['details']
 def parent_record(self,rel):
  p=self.parent/rel;expected=self.context['parent_pins'][rel]
  if sha(p)!=expected:raise ValueError('Parent record differs from reviewed inventory: '+rel)
  return read(p)
 def report(self,status,errors):
  summary={'status':status,'errors':errors,'models_fitted':0,'general_independent_site_validation_completed':False,'natural_production_prevalence_established':False,'prior_labels_and_inventory_known':True};write(self.local/'summary.json',summary)
  try:self.upload('summary.json')
  except OSError:print('Drive unavailable; local report retained.')
  files=[p for p in self.local.rglob('*') if p.is_file() and 'cache' not in p.parts and p.suffix in ('.json','.md','.py','.csv') and p.name!='SHA256SUMS.json'];write(self.local/'SHA256SUMS.json',{str(p.relative_to(self.local)):sha(p) for p in files});stamp=datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f');zp=self.local.parent/f'ctu13_partition_qualification_report_{stamp}.zip'
  with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
   for p in files+[self.local/'SHA256SUMS.json']:z.write(p,str(p.relative_to(self.local)))
  try:
   dst=self.remote.parent/zp.name;tmp=dst.with_suffix('.zip.tmp');shutil.copyfile(zp,tmp)
   if sha(tmp)!=sha(zp):raise IOError('Report copy mismatch')
   tmp.replace(dst);print('Drive report:',dst,flush=True)
  except OSError:print('Use the local report download. Drive copy unavailable.',flush=True)
  print(status,flush=True);return zp

def validate_parent(w):
 if read(w.parent/'identity.json')!=w.context['parent_identity']:raise ValueError('Inventory identity changed')
 old=w.cached('parent.complete.json')
 if old is not None:return old
 outputs=[]
 for i,(rel,h) in enumerate(w.context['parent_pins'].items()):
  p=w.parent/rel
  if sha(p)!=h:raise ValueError('Parent recorded file differs: '+rel)
  # Pin all reviewed records; preserve a compact witness summary, not a second full copy.
  if (i+1)%50==0:print('Verified parent records',i+1,'/',len(w.context['parent_pins']),flush=True)
 summary={'recorded_files_verified':len(w.context['parent_pins']),'identity_matches':True,'input_raw_hashes_pinned':13,'original_report_sha256':w.context['parent_report_sha256']};write(w.local/'parent_validation.json',summary);w.finish('parent.complete.json',['parent_validation.json'],summary);return summary

def known_keys(w,sid):
 tag=f'scenario_{sid:02d}';old=w.cached(tag+'/keys.complete.json')
 if old is not None:return load(w.local/old['path'])['records']
 inv=w.context['inventory'][str(sid)]
 if inv['bad_lines'] or inv['physical_data_lines']!=inv['parsed_rows']:raise ValueError('This qualification requires the reviewed one-physical-line-per-record inventory')
 parts=[];prior_rows=0;inputhash=inv['input_sha256']
 for k,mref in enumerate(w.context['chunks'][str(sid)]):
  m=w.parent_record(mref['marker']);d=m['details']
  if m['identity']!=w.context['parent_identity'] or digest(d)!=m['details_sha256'] or d['input_sha256']!=inputhash:raise ValueError('Parent chunk record identity/details changed')
  rel=d['shard'];src=w.parent/rel;expected=m['outputs'][rel];cache=w.local/'cache'/'one_digest.npy';cache.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,cache)
  if sha(cache)!=expected:raise ValueError('Parent digest shard hash mismatch: '+rel)
  ar=np.load(cache,mmap_mode='r',allow_pickle=False)
  if ar.dtype!=PARENT_DTYPE or len(ar)!=d['stats']['parsed_rows']-prior_rows:raise ValueError('Digest shard dtype/row alignment differs')
  mask=ar['valid']&(ar['cls']<2);pos=np.flatnonzero(mask);out=np.empty(len(pos),dtype=KNOWN_DTYPE);out['sig']=ar['feature'][pos];out['event']=ar['event'][pos];out['label']=ar['label'][pos];out['y']=ar['cls'][pos];out['row']=prior_rows+pos;parts.append(out);prior_rows=d['stats']['parsed_rows'];del ar;cache.unlink()
  if (k+1)%10==0:print(f'Scenario {sid}: verified digest chunks {k+1}/{len(w.context["chunks"][str(sid)])}',flush=True)
 records=np.concatenate(parts) if parts else np.empty(0,dtype=KNOWN_DTYPE);expected=inv['eligible_projection_binary_rows'];assert int((records['y']==0).sum())==expected['benign'] and int((records['y']==1).sum())==expected['attack'];assert prior_rows==inv['parsed_rows']
 path=tag+'/known_records.npz';npz(w.local/path,records=records);details={'scenario':sid,'path':path,'known_occurrences':len(records),'benign':int((records['y']==0).sum()),'attack':int((records['y']==1).sum()),'raw_input_sha256':inputhash};write(w.local/(tag+'/keys.json'),details);w.finish(tag+'/keys.complete.json',[path,tag+'/keys.json'],details);return records

def global_conflicts(w):
 old=w.cached('conflicts.complete.json')
 if old is not None:return load(w.local/'conflicting_signatures.npz')['signatures']
 arrays=[[],[]];counts=[]
 for sid in range(1,14):
  ar=known_keys(w,sid);counts.append({'scenario':sid,'known_rows':len(ar)})
  for y in [0,1]:arrays[y].append(np.unique(ar['sig'][ar['y']==y]))
 benign=np.unique(np.concatenate(arrays[0]));attack=np.unique(np.concatenate(arrays[1]));conflicts=np.intersect1d(benign,attack,assume_unique=True)
 if len(conflicts)!=w.context['expected_conflicting_known_projection_signatures']:raise ValueError('Reconstructed conflict count does not reproduce reviewed inventory')
 npz(w.local/'conflicting_signatures.npz',signatures=conflicts);details={'conflicting_signatures':len(conflicts),'unique_known_benign_signatures':len(benign),'unique_known_attack_signatures':len(attack),'known_occurrences_by_scenario':counts,'unknown_rows_used_as_known_labels':0,'rule':'Remove every signature carrying both known classes anywhere among all 13 audited scenarios; target labels inform this post hoc cohort restriction.'};write(w.local/'conflict_summary.json',details);w.finish('conflicts.complete.json',['conflicting_signatures.npz','conflict_summary.json'],details);return conflicts

def canonical(vals):
 row={k:v.strip() for k,v in zip(COLUMNS,vals)};label=row['Label'];y=1 if re.match(r'^flow=From-Botnet(?:-|$)',label) else 0 if re.match(r'^flow=From-Normal(?:-|$)',label) else 2
 proto=row['Proto'].lower()
 if proto not in ('tcp','udp') or y==2:raise ValueError('Selected known projection row has unexpected label/protocol')
 nums={k:Decimal(row[k]) for k in ['Dur','TotPkts','TotBytes','SrcBytes']}
 for k,v in nums.items():
  if not v.is_finite() or not 0<=v<=2**53-1 or (k!='Dur' and v!=v.to_integral_value()):raise ValueError('Invalid selected numeric field')
 port=int(row['Dport'],16) if row['Dport'].lower().startswith('0x') else int(row['Dport'])
 if not 0<=port<=65535 or nums['SrcBytes']>nums['TotBytes']:raise ValueError('Selected row fails audit projection')
 dur=float(nums['Dur'])
 if Decimal(str(dur))!=nums['Dur']:raise ValueError('Float64 duration loses the audited decimal value; cannot silently reuse signature disjointness')
 parts=[proto,str(port)]+[format(nums[k].normalize(),'f') for k in ['Dur','TotPkts','TotBytes','SrcBytes']];sig=hashlib.sha256(json.dumps(parts,separators=(',',':')).encode()).digest();event=hashlib.sha256(json.dumps([row[k] for k in COLUMNS if k!='Label'],separators=(',',':')).encode()).digest();dt=datetime.fromisoformat(row['StartTime'].replace('/','-'))
 if dt.tzinfo is not None:raise ValueError('Unexpected timezone-aware timestamp')
 block=dt.replace(minute=dt.minute//30*30,second=0,microsecond=0).isoformat(sep=' ');x=[1. if proto=='tcp' else 0.,float(port),dur,float(nums['TotPkts']),float(nums['TotBytes']),float(nums['SrcBytes'])];return np.array(x,dtype='float64'),y,label,sig,event,block

def copy_pinned_raw(w,sid):
 rec=w.context['raw_inputs'][str(sid)];src=w.parent/'inputs'/f'scenario_{sid:02d}.binetflow';dst=w.local/'cache'/f'scenario_{sid:02d}.binetflow';dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists() and sha(dst)==rec['sha256']:return dst
 tmp=dst.with_suffix('.tmp');h=hashlib.sha256()
 with src.open('rb') as f,tmp.open('wb') as g:
  for data in iter(lambda:f.read(4*1024*1024),b''):h.update(data);g.write(data)
 if tmp.stat().st_size!=rec['remote']['bytes'] or h.hexdigest()!=rec['sha256']:raise ValueError('Raw input differs from pinned inventory: '+str(src))
 tmp.replace(dst);return dst

def pool(w,sid,conflicts):
 tag=f'scenario_{sid:02d}';old=w.cached(tag+'/pool.complete.json')
 if old is not None:return load(w.local/old['path'])
 records=known_keys(w,sid);keep=~np.isin(records['sig'],conflicts);ret=records[keep];u,idx=np.unique(ret['sig'],return_index=True);reps=ret[np.sort(idx)];rows=reps['row'];n=len(reps);x=np.empty((n,6),dtype='float64');y=reps['y'].copy();sig=reps['sig'].copy();blocks=np.empty(n,dtype='U19');label_order=w.context['inventory'][str(sid)]['label_order'];raw=copy_pinned_raw(w,sid);done=0;prior_rows=0
 with raw.open('rb') as f:
  header=next(csv.reader([f.readline().decode('utf-8-sig').rstrip('\r\n')]))
  if header!=COLUMNS:raise ValueError('Raw header differs from reviewed schema')
  start=f.tell()
  for k,mref in enumerate(w.context['chunks'][str(sid)]):
   m=w.parent_record(mref['marker']);end=m['details']['next_offset'];nrows=m['details']['stats']['parsed_rows']-prior_rows;lo=int(np.searchsorted(rows,prior_rows));hi=int(np.searchsorted(rows,prior_rows+nrows))
   if hi>lo:
    f.seek(start);data=f.read(end-start);lines=data.split(b'\n')
    if lines and lines[-1]==b'':lines.pop()
    if len(lines)!=nrows:raise ValueError('Raw line/chunk alignment does not reproduce inventory')
    for i in range(lo,hi):
     line=lines[int(rows[i])-prior_rows].decode('utf-8').rstrip('\r');vals=next(csv.reader([line],strict=True))
     if len(vals)!=len(COLUMNS):raise ValueError('Raw selected row width differs')
     xx,yy,label,ss,event,block=canonical(vals)
     if yy!=int(y[i]) or bytes32(sig[i])!=ss or bytes32(reps['event'][i])!=event or label!=label_order[int(reps['label'][i])]:raise ValueError('Selected representative row does not align with pinned digest/label')
     x[i]=xx;blocks[i]=block;done+=1
   start=end;prior_rows+=nrows
   if (k+1)%10==0:print(f'Scenario {sid}: recovered representative chunks {k+1}/{len(w.context["chunks"][str(sid)])}',flush=True)
 if done!=n:raise ValueError('Representative recovery incomplete')
 # Roundtrip checks above ensure decimal signature equality and Float64 representation are consistent on every retained representative.
 arr={'x':x,'y':y,'signature':sig,'row_index':rows,'block':blocks};path=tag+'/pool.npz';npz(w.local/path,**arr);details={'scenario':sid,'path':path,'input_known_occurrences':len(records),'conflicting_known_occurrences_removed':int((~keep).sum()),'retained_known_occurrences':len(ret),'duplicate_known_occurrences_removed':len(ret)-n,'unique_representatives':n,'benign':int((y==0).sum()),'attack':int((y==1).sum()),'unknown_used':0,'numeric_features':FEATURES,'float64_decimal_roundtrip_checked':True,'timestamp_timezone_established':False,'raw_input_sha256':w.context['raw_inputs'][str(sid)]['sha256'],'representative_rule':'First known eligible raw occurrence within own capture, after global known-binary conflict removal.'};write(w.local/(tag+'/pool.json'),details);w.finish(tag+'/pool.complete.json',[path,tag+'/pool.json'],details)
 raw.unlink() # Only this new stage's disposable local copy; original Drive input remains unchanged.
 print(f'Scenario {sid}: retained {n:,} unique known representatives',flush=True);return arr

def choose(indices,signatures,seed,tag,n):
 indices=np.asarray(indices,dtype='int64');order=sorted(indices.tolist(),key=lambda i:priority(tag,seed,signatures[i]));return np.sort(np.array(order[:n],dtype='int64'))
def qualify(arr,sid,seed,config):
 y=arr['y'];sig=arr['signature'];role=role_assignment(sig,seed,config);selected={};details={'scenario':sid,'seed':seed,'roles':{},'environment_windows':[],'initial_source_candidate':sid in config['initial_source_candidates']}
 for j,name in enumerate(['train','calibration','test']):
  counts=[int(np.count_nonzero((role==j)&(y==c))) for c in [0,1]];floor=config[name+'_min_per_class'];cap=config[name+'_cap_per_class'];n=min(cap,*counts);passed=n>=floor
  ids=np.concatenate([choose(np.flatnonzero((role==j)&(y==c)),sig,seed,name+f'-class-{c}',n) for c in [0,1]]) if passed else np.array([],dtype='int64');selected[name]=ids;details['roles'][name]={'available_benign':counts[0],'available_attack':counts[1],'minimum_per_class':floor,'cap_per_class':cap,'selected_per_class':n if passed else 0,'support_pass':passed,'rows':len(ids)}
 env=[];actual=[];quota=config['environment_class_quota'];allblocks=sorted(set(arr['block'][role==3].tolist()))
 for block in allblocks:
  ids=[np.flatnonzero((role==3)&(y==c)&(arr['block']==block)) for c in [0,1]];counts=list(map(len,ids));passed=min(counts)>=quota;details['environment_windows'].append({'block':block,'available_benign':counts[0],'available_attack':counts[1],'retained':passed})
  if passed:
   group=len(env);picked=np.concatenate([choose(ids[c],sig,seed,'environment-'+block+f'-class-{c}',quota) for c in [0,1]]);env.append(picked);actual.extend([group]*len(picked))
 selected['environment']=np.concatenate(env) if env else np.array([],dtype='int64');actual=np.array(actual,dtype='int32');pseudo=np.full(len(actual),-1,dtype='int32')
 for c in [0,1]:
  ii=np.flatnonzero(y[selected['environment']]==c);order=sorted(ii.tolist(),key=lambda i:priority('pseudo-'+str(sid)+f'-class-{c}',seed,sig[selected['environment'][i]]));pseudo[np.asarray(order,dtype='int64')]=np.repeat(np.arange(len(env),dtype='int32'),quota)
 assert np.all(pseudo>=0)
 for g in range(len(env)):
  for part in [actual,pseudo]:assert all(np.count_nonzero((part==g)&(y[selected['environment']]==c))==quota for c in [0,1])
 for a,b in combinations(selected,2):assert len(np.intersect1d(sig[selected[a]],sig[selected[b]]))==0
 details.update(environment_groups=len(env),environment_rows=len(selected['environment']),environment_quota_per_class=quota,environment_min_groups=config['minimum_environment_windows'],environment_support_pass=len(env)>=config['minimum_environment_windows'],target_support_pass=details['roles']['test']['support_pass'])
 details['source_support_pass']=details['initial_source_candidate'] and all(details['roles'][n]['support_pass'] for n in ['train','calibration','test']) and details['environment_support_pass']
 details['role_assignment_rule']='SHA-256(global-role, seed, signature) first 8 bytes modulo 100; common across every capture in a seed; 30/10/10/50 percent bands'
 return selected,actual,pseudo,details

def build_panels(w,sid,seed,arr):
 tag=f'scenario_{sid:02d}/seed_{seed}';old=w.cached(tag+'/panels.complete.json')
 if old is not None:return old
 selected,actual,pseudo,details=qualify(arr,sid,seed,w.config);outputs=[];paths={}
 for name,ids in selected.items():
  path=tag+'/'+name+'.npz';data={k:v[ids] for k,v in arr.items()};data['pool_index']=ids
  if name=='environment':data.update(actual_group=actual,pseudo_group=pseudo)
  npz(w.local/path,**data);outputs.append(path);paths[name]={'path':path,'sha256':sha(w.local/path),'rows':len(ids),'benign':int((arr['y'][ids]==0).sum()),'attack':int((arr['y'][ids]==1).sum())}
 details['panels']=paths;details['training_constant_columns']=[FEATURES[i] for i in range(6) if len(selected['train']) and np.ptp(arr['x'][selected['train'],i])==0];details['models_fitted']=0
 path=tag+'/qualification.json';write(w.local/path,details);outputs.append(path);w.finish(tag+'/panels.complete.json',outputs,details);return details

def cross_role_check(w,qualifications):
 old=w.cached('cross_role.complete.json')
 if old is not None:return old
 report=[]
 for seed in w.config['seeds']:
  union={}
  for name in ['train','calibration','test','environment']:
   sig=[]
   for d in qualifications:
    if d['seed']==seed:sig.append(load(w.local/d['panels'][name]['path'])['signature'])
   union[name]=np.unique(np.concatenate(sig)) if sig else np.array([],dtype='S32')
  checks={f'{a}__{b}':len(np.intersect1d(union[a],union[b],assume_unique=True)) for a,b in combinations(union,2)}
  if any(checks.values()):raise ValueError('Cross-capture cross-role signature overlap detected')
  report.append({'seed':seed,'role_union_unique_counts':{k:len(v) for k,v in union.items()},'cross_role_intersections':checks})
 details={'results':report,'all_cross_capture_cross_role_intersections_zero':True,'same_role_cross_capture_repeats_allowed':True,'seeds_are_not_independent_environments':True,'model_representation_roundtrip_checked':True};write(w.local/'cross_role_audit.json',details);w.finish('cross_role.complete.json',['cross_role_audit.json'],details);return details

def run(paper3_root,context,source,plan,local_root='/content/paper3_ctu_qualification',config=None):
 config=dict(DEFAULT if config is None else config);config['initial_source_candidates']=context['initial_source_candidates'];w=Workspace(paper3_root,context,source,plan,local_root,config);errors=[];details=[];started=time.monotonic()
 try:
  validate_parent(w);conflicts=global_conflicts(w)
  for sid in range(1,14):
   print(f'\nQualifying scenario {sid}/13',flush=True);arr=pool(w,sid,conflicts)
   for seed in config['seeds']:details.append(build_panels(w,sid,seed,arr))
  cross_role_check(w,details)
  sources=[sid for sid in context['initial_source_candidates'] if all(d['source_support_pass'] for d in details if d['scenario']==sid)];targets=[sid for sid in range(1,14) if all(d['target_support_pass'] for d in details if d['scenario']==sid)];directions=[[s,t] for s in sources for t in targets if s!=t]
  gate={'qualified_sources_all_seeds':sources,'qualified_targets_all_seeds':targets,'available_directed_cases':directions,'qualified_source_count':len(sources),'qualified_target_count':len(targets),'cases_count':len(directions),'ready_for_bounded_model_pilot':bool(directions),'qualified_for_independent_institution_warning_inference':False,'qualified_for_natural_production_prevalence':False,'models_fitted':0,'support_thresholds_relaxed':False,'seeds':config['seeds'],'post_hoc_label_informed_global_conflict_exclusion':True,'one_institution':True,'class_balanced_known_label_representative_cohort':True,'session_seconds':time.monotonic()-started}
  for key in ['same_documented_binary_groups']:gate[key]=w.parent_record('gate_decision.json')[key]
  write(w.local/'gate_decision.json',gate);w.finish('qualification.complete.json',['gate_decision.json'],gate)
  with (w.local/'qualification_summary.csv').open('w',newline='') as f:
   rows=[{'scenario':d['scenario'],'seed':d['seed'],'train_rows':d['roles']['train']['rows'],'calibration_rows':d['roles']['calibration']['rows'],'test_rows':d['roles']['test']['rows'],'environment_groups':d['environment_groups'],'source_pass':d['source_support_pass'],'target_pass':d['target_support_pass']} for d in details];writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
  w.upload('qualification_summary.csv')
 except Exception as ex:
  errors.append({'type':type(ex).__name__,'message':str(ex)});print('Qualification stopped safely:',errors[-1],flush=True)
 status='CTU13_PARTITION_QUALIFICATION_COMPLETE' if not errors else 'CTU13_PARTITION_QUALIFICATION_PARTIAL_RESUMABLE'
 return w.report(status,errors)
