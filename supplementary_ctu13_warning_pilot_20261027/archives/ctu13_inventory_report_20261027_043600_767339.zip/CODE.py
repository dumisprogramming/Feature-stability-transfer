"""CTU-13 inventory only. No training, executable downloads or population-prevalence claim."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
from decimal import Decimal,InvalidOperation
from itertools import combinations
import csv,json,hashlib,urllib.request,urllib.error,re,shutil,time,platform,math,traceback,zipfile,os
import numpy as np
STAGE='supplementary_ctu13_inventory_20261027'
COLUMNS=['StartTime','Dur','Proto','SrcAddr','Sport','Dir','DstAddr','Dport','State','sTos','dTos','TotPkts','TotBytes','SrcBytes','Label']
DTYPE=np.dtype([('feature','S32'),('event','S32'),('label','<u2'),('cls','u1'),('valid','?')])
AGG=np.dtype([('sig','S32'),('scenario','u1'),('label','<u2'),('cls','u1')])
EDGES=[0.,.001,.01,.1,1.,10.,60.,600.,3600.]
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(4*1024*1024),b''):h.update(block)
 return h.hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,allow_nan=False).encode()).hexdigest()
def write(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(path)
def read(p):return json.loads(Path(p).read_text())
def binary(label):
 if re.match(r'^flow=From-Botnet(?:-|$)',label):return 1
 if re.match(r'^flow=From-Normal(?:-|$)',label):return 0
 return 2

def response_identity(headers):
 return {'bytes':int(headers['Content-Length']),'etag':headers.get('ETag'),'last_modified':headers.get('Last-Modified')}
def remote_identity(url):
 with urllib.request.urlopen(urllib.request.Request(url,method='HEAD',headers={'Accept-Encoding':'identity'}),timeout=45) as r:
  if r.status!=200 or not r.headers.get('Content-Length'):raise ValueError('HEAD did not provide exact length')
  return response_identity(r.headers)

def download(url,dest,expected,opener=urllib.request.urlopen,retries=4):
 """Range-resume one data file. Never append a whole-file 200 response to a partial file."""
 dest=Path(dest);dest.parent.mkdir(parents=True,exist_ok=True);marker=dest.with_suffix(dest.suffix+'.download.json');part=dest.with_suffix(dest.suffix+'.part');pending=dest.with_suffix(dest.suffix+'.pending.json')
 if marker.exists():
  m=read(marker)
  if m['url']!=url or m['remote']!=expected:raise ValueError('Download identity changed: '+dest.name)
  if dest.exists():
   if dest.stat().st_size!=expected['bytes'] or sha(dest)!=m['sha256']:raise ValueError('Completed input hash changed: '+dest.name)
   return m
 if dest.exists():
  if not pending.exists():raise ValueError('Unrecorded complete input exists: '+str(dest))
  m=read(pending)
  if m['url']!=url or m['remote']!=expected or dest.stat().st_size!=expected['bytes'] or sha(dest)!=m['sha256']:raise ValueError('Interrupted input commit does not match')
  write(marker,m);pending.unlink();return m
 if part.exists() and part.stat().st_size>expected['bytes']:raise ValueError('Oversized partial input')
 for attempt in range(retries):
  start=part.stat().st_size if part.exists() else 0
  if start==expected['bytes']:break
  headers={'Accept-Encoding':'identity','User-Agent':'Paper3-CTU13-public-flow-inventory'}
  if start:headers['Range']=f'bytes={start}-'
  validator=expected.get('etag') or expected.get('last_modified')
  if start and validator:headers['If-Range']=validator
  try:
   with opener(urllib.request.Request(url,headers=headers),timeout=90) as r:
    status=r.status
    if start:
     match=re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)',r.headers.get('Content-Range',''))
     if status!=206 or not match or int(match[1])!=start or int(match[3])!=expected['bytes']:raise ValueError('Server did not honour resume range; partial file retained')
    elif status not in (200,206):raise ValueError('Unexpected data response')
    if status==206:
     match=re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)',r.headers.get('Content-Range',''))
     if not match or int(match[1])!=start or int(match[3])!=expected['bytes']:raise ValueError('Invalid Content-Range')
    for key,hkey in [('etag','ETag'),('last_modified','Last-Modified')]:
     if expected.get(key) and r.headers.get(hkey)!=expected[key]:raise ValueError('Remote validator changed: '+dest.name)
    with part.open('ab' if start else 'wb') as f:
     last=start
     while True:
      data=r.read(2*1024*1024)
      if not data:break
      if f.tell()+len(data)>expected['bytes']:raise ValueError('Response longer than pinned file')
      f.write(data)
      if f.tell()-last>=32*1024*1024:
       f.flush();print(f'Download {dest.name}: {f.tell()/2**20:.0f}/{expected["bytes"]/2**20:.0f} MiB',flush=True);last=f.tell()
    if part.stat().st_size==expected['bytes']:break
   if attempt==retries-1:raise IOError('Incomplete download after retries')
  except (OSError,urllib.error.URLError,TimeoutError):
   if attempt==retries-1:raise
   time.sleep(min(attempt+1,3))
 if not part.exists() or part.stat().st_size!=expected['bytes']:raise IOError('Incomplete input retained for resume')
 h=sha(part);m={'url':url,'remote':expected,'sha256':h};write(pending,m);part.replace(dest);write(marker,m);pending.unlink();return m

class Workspace:
 def __init__(self,paper3_root,local_root,source,registry,plan,chunk_rows=100000):
  self.remote=Path(paper3_root)/STAGE/'run_v1';self.local=Path(local_root)/STAGE/'run_v1';self.remote.mkdir(parents=True,exist_ok=True);self.local.mkdir(parents=True,exist_ok=True);self.chunk_rows=chunk_rows
  self.identity={'code_sha256':hashlib.sha256(source.encode()).hexdigest(),'registry_sha256':digest(registry),'plan_sha256':hashlib.sha256(plan.encode()).hexdigest(),'chunk_rows':chunk_rows,'python':platform.python_version(),'numpy':np.__version__}
  if (self.remote/'identity.json').exists() and read(self.remote/'identity.json')!=self.identity:raise ValueError('Resume identity differs. Keep the old stage and use the unchanged notebook/runtime.')
  for name,value in [('identity.json',self.identity),('registry.json',registry)]:write(self.local/name,value)
  (self.local/'CODE.py').write_text(source);(self.local/'PLAN.md').write_text(plan)
  for n in ['identity.json','registry.json','CODE.py','PLAN.md']:self.upload(n)
 def upload(self,rel):
  src=self.local/rel;dst=self.remote/rel;dst.parent.mkdir(parents=True,exist_ok=True);tmp=dst.with_suffix(dst.suffix+'.tmp');shutil.copyfile(src,tmp)
  if sha(tmp)!=sha(src):raise IOError('Drive copy mismatch '+rel)
  tmp.replace(dst)
 def finish(self,marker,outputs,details):
  rec={'identity':self.identity,'outputs':{n:sha(self.local/n) for n in outputs},'details':details,'details_sha256':digest(details)}
  for n in outputs:self.upload(n)
  write(self.local/marker,rec);self.upload(marker)
 def cached(self,marker):
  path=self.remote/marker
  if not path.exists():return None
  m=read(path)
  if m['identity']!=self.identity or digest(m['details'])!=m['details_sha256']:raise ValueError('Checkpoint identity/details changed: '+marker)
  for n,h in m['outputs'].items():
   p=self.remote/n
   if sha(p)!=h:raise ValueError('Checkpoint output changed: '+n)
   dst=self.local/n;dst.parent.mkdir(parents=True,exist_ok=True)
   if not dst.exists() or sha(dst)!=h:shutil.copyfile(p,dst)
  dst=self.local/marker;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dst);return m['details']
 def report(self,status,errors):
  summary={'status':status,'errors':errors,'models_fitted':0,'natural_production_prevalence_established':False,'common_exporter_equivalence_established':False,'audit_is_not_general_warning_validation':True}
  write(self.local/'summary.json',summary)
  try:self.upload('summary.json')
  except OSError:print('Drive unavailable; local report retained.',flush=True)
  # Raw inputs, per-row digest shards and temporary files are never included.
  files=[p for p in self.local.rglob('*') if p.is_file() and p.suffix in ('.json','.md','.py','.csv') and 'cache' not in p.parts and not p.name.endswith('.tmp') and p.name!='SHA256SUMS.json']
  write(self.local/'SHA256SUMS.json',{str(p.relative_to(self.local)):sha(p) for p in files});stamp=datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f');out=self.local.parent/f'ctu13_inventory_report_{stamp}.zip'
  with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
   for p in files+[self.local/'SHA256SUMS.json']:z.write(p,str(p.relative_to(self.local)))
  try:
   dst=self.remote.parent/out.name;tmp=dst.with_suffix('.zip.tmp');shutil.copyfile(out,tmp)
   if sha(tmp)!=sha(out):raise IOError('Report copy mismatch')
   tmp.replace(dst);print('Drive report:',dst,flush=True)
  except OSError:print('Use the local report download; Drive copy unavailable.',flush=True)
  print(status,flush=True);return out

def acquire(w,entry):
 sid=entry['scenario'];tag=f'scenario_{sid:02d}';marker=tag+'/metadata.complete.json';cached=w.cached(marker)
 if cached is not None:return cached
 # Exact allow-listed flow path only. No executable archive, PCAP or dynamic directory crawl.
 url=entry['flow_url'];meta=remote_identity(url)
 if entry.get('expected_bytes') is not None and meta['bytes']!=entry['expected_bytes']:raise ValueError('Origin length differs from preparation preflight')
 if entry.get('preflight_prefix_sha256'):
  n=entry['preflight_prefix_bytes']
  with urllib.request.urlopen(urllib.request.Request(url,headers={'Range':f'bytes=0-{n-1}','Accept-Encoding':'identity'}),timeout=45) as r:prefix=r.read(n)
  if hashlib.sha256(prefix).hexdigest()!=entry['preflight_prefix_sha256']:raise ValueError('Origin prefix differs from preparation preflight')
 details={'scenario':sid,'capture':entry['capture'],'flow_url':url,'remote':meta,'documents':{},'documented_binary_sha256':None,'probable_malware':None,'timezone_status':'not_established_from_naive_flow_timestamps'}
 for name,u in entry['documents'].items():
  try:
   with urllib.request.urlopen(u,timeout=30) as r:data=r.read(1024*1024+1)
   if len(data)>1024*1024:raise ValueError('Documentation exceeds 1 MiB bound')
   text=data.decode('utf-8');rel=tag+'/'+name+'.txt';p=w.local/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);details['documents'][name]={'url':u,'sha256':sha(p),'path':rel}
   if name=='README':
    m=re.search(r'SHA256:\s*([0-9a-fA-F]{64})',text);details['documented_binary_sha256']=m[1].lower() if m else None
    m=re.search(r'Probable (?:Malware )?Name:\s*([^\r\n]+)',text);details['probable_malware']=m[1].strip() if m else None
    ips=sorted(set(re.findall(r'\b(?:\d{1,3}\.){3}\d{1,3}\b',text)));details['readme_address_mention_hashes']=[hashlib.sha256(x.encode()).hexdigest() for x in ips]
  except Exception as e:details['documents'][name]={'url':u,'error':str(e)}
 rel=tag+'/metadata.json';write(w.local/rel,details);outputs=[rel]+[x['path'] for x in details['documents'].values() if 'path' in x];w.finish(marker,outputs,details);return details

def initial_stats():
 return {'physical_data_lines':0,'parsed_rows':0,'malformed_rows':0,'decode_errors':0,'blank_lines':0,'labels':{},'label_order':[],'binary_rows':{'benign':0,'attack':0,'unknown':0},'protocol_rows':{},'missing_fields':{},'invalid_numeric_fields':{},'eligible_projection_rows':0,'eligible_projection_binary_rows':{'benign':0,'attack':0,'unknown':0},'timestamp_missing_or_invalid':0,'timestamp_min':None,'timestamp_max':None,'windows':{},'duration_seconds':{'count':0,'sum':0.,'min':None,'max':None,'zero':0,'histogram_upper_bounds':[.001,.01,.1,1.,10.,60.,600.,3600.,None],'histogram_counts':[0]*9}}
def inc(d,k):d[k]=d.get(k,0)+1

def process_row(vals,stats):
 stats['parsed_rows']+=1;row=dict(zip(COLUMNS,[s.strip() for s in vals]));label=row['Label'];inc(stats['labels'],label)
 if label not in stats['label_order']:stats['label_order'].append(label)
 lid=stats['label_order'].index(label)
 if lid>65535:raise ValueError('Too many distinct exact labels')
 cls=binary(label);inc(stats['binary_rows'],['benign','attack','unknown'][cls]);proto=row['Proto'].lower();inc(stats['protocol_rows'],proto)
 for k,x in row.items():
  if x in ('','-'):inc(stats['missing_fields'],k)
 try:
  dt=datetime.fromisoformat(row['StartTime'].replace('/','-'));stamp=dt.isoformat(sep=' ')
  if dt.tzinfo is not None:raise ValueError('Unexpected timezone-aware time')
  stats['timestamp_min']=stamp if stats['timestamp_min'] is None else min(stamp,stats['timestamp_min']);stats['timestamp_max']=stamp if stats['timestamp_max'] is None else max(stamp,stats['timestamp_max']);window=dt.replace(minute=dt.minute//30*30,second=0,microsecond=0).isoformat(sep=' ')
 except (ValueError,OverflowError):stats['timestamp_missing_or_invalid']+=1;window=None
 numeric={};canon={}
 for k in ['Dur','TotPkts','TotBytes','SrcBytes']:
  try:
   v=Decimal(row[k])
   if not v.is_finite() or v<0 or v>2**53-1 or (k!='Dur' and v!=v.to_integral_value()):raise ValueError('Out of canonical domain')
   numeric[k]=float(v);canon[k]=format(v.normalize(),'f')
  except (InvalidOperation,ValueError):inc(stats['invalid_numeric_fields'],k)
 if 'Dur' in numeric:
  v=numeric['Dur'];d=stats['duration_seconds'];d['count']+=1;d['sum']+=v;d['min']=v if d['min'] is None else min(v,d['min']);d['max']=v if d['max'] is None else max(v,d['max']);d['zero']+=int(v==0);idx=int(np.searchsorted([.001,.01,.1,1.,10.,60.,600.,3600.],v,side='right'));d['histogram_counts'][idx]+=1
 try:
  s=row['Dport'];port=int(s,16) if s.lower().startswith('0x') else int(s)
  if not 0<=port<=65535:raise ValueError('Invalid port')
 except ValueError:port=None;inc(stats['invalid_numeric_fields'],'Dport')
 valid=proto in ('tcp','udp') and port is not None and len(canon)==4 and numeric['SrcBytes']<=numeric['TotBytes']
 if len(canon)==4 and numeric['SrcBytes']>numeric['TotBytes']:inc(stats['invalid_numeric_fields'],'SrcBytes_exceeds_TotBytes')
 if valid:
  components=[proto,str(port),canon['Dur'],canon['TotPkts'],canon['TotBytes'],canon['SrcBytes']];sig=hashlib.sha256(json.dumps(components,separators=(',',':')).encode()).digest();stats['eligible_projection_rows']+=1;inc(stats['eligible_projection_binary_rows'],['benign','attack','unknown'][cls])
 else:sig=b'\0'*32
 if window:
  q=stats['windows'].setdefault(window,{'all_parsed':0,'eligible_benign':0,'eligible_attack':0,'eligible_unknown':0});q['all_parsed']+=1
  if valid:q['eligible_'+['benign','attack','unknown'][cls]]+=1
 # Exact stripped-field event identity includes endpoints and timestamp, excludes Label.
 event=hashlib.sha256(json.dumps([row[k] for k in COLUMNS if k!='Label'],separators=(',',':')).encode()).digest()
 return sig,event,lid,cls,valid

def scan(w,entry,input_path,input_hash):
 sid=entry['scenario'];tag=f'scenario_{sid:02d}';complete=w.cached(tag+'/scan.complete.json')
 if complete is not None:
  if complete['input_sha256']!=input_hash:raise ValueError('Scan input changed')
  return complete
 stats=initial_stats();chunk=0;offset=None;shards=[]
 while True:
  marker=f'{tag}/chunks/chunk_{chunk:05d}.complete.json';old=w.cached(marker)
  if old is None:break
  if old['input_sha256']!=input_hash:raise ValueError('Chunk input changed')
  stats=old['stats'];offset=old['next_offset'];shards.append(old['shard']);chunk+=1
 if chunk:print(f'Resume scenario {sid}: {stats["physical_data_lines"]:,} lines already audited',flush=True)
 with Path(input_path).open('rb') as f:
  first=f.readline();header=next(csv.reader([first.decode('utf-8-sig').rstrip('\r\n')]))
  if header!=COLUMNS:raise ValueError('Unexpected standard binetflow schema')
  if offset is not None:f.seek(offset)
  eof=False;scan_started=time.monotonic()
  while not eof:
   arr=[];n=0
   while n<w.chunk_rows:
    line=f.readline()
    if not line:eof=True;break
    n+=1;stats['physical_data_lines']+=1
    if not line.strip():stats['blank_lines']+=1;continue
    try:val=next(csv.reader([line.decode('utf-8').rstrip('\r\n')],strict=True))
    except UnicodeDecodeError:stats['decode_errors']+=1;continue
    except (csv.Error,StopIteration):stats['malformed_rows']+=1;continue
    if len(val)!=len(COLUMNS):stats['malformed_rows']+=1;continue
    arr.append(process_row(val,stats))
   if n:
    rel=f'{tag}/chunks/chunk_{chunk:05d}.npy';path=w.local/rel;path.parent.mkdir(parents=True,exist_ok=True);np.save(path,np.asarray(arr,dtype=DTYPE),allow_pickle=False)
    details={'input_sha256':input_hash,'next_offset':f.tell(),'shard':rel,'stats':stats};w.finish(f'{tag}/chunks/chunk_{chunk:05d}.complete.json',[rel],details);shards.append(rel);chunk+=1;print(f'Scenario {sid}: audited {stats["physical_data_lines"]:,} lines; {100*f.tell()/Path(input_path).stat().st_size:.1f}% of file bytes; session scan {time.monotonic()-scan_started:.0f}s',flush=True)
 assert stats['physical_data_lines']==stats['parsed_rows']+stats['malformed_rows']+stats['decode_errors']+stats['blank_lines']
 assert sum(stats['labels'].values())==sum(stats['binary_rows'].values())==stats['parsed_rows']
 stats['eligible_30min_windows_at_100_per_known_class']=sum(x['eligible_benign']>=100 and x['eligible_attack']>=100 for x in stats['windows'].values())
 out={'scenario':sid,'input_sha256':input_hash,'header':header,'stats':stats,'shards':shards,'timezone_established':False,'projection_is_original_six_fields':False,'projection_components':['protocol','destination_port','duration_seconds','total_packets','total_bytes','source_bytes'],'natural_production_prevalence_claim':False}
 rel=tag+'/inventory.json';write(w.local/rel,out);w.finish(tag+'/scan.complete.json',[rel],out);return out

def bucket_records(shards,field,bucket):
 parts=[];max_records=5000000
 for scenario,p in shards:
  ar=np.load(p,mmap_mode='r',allow_pickle=False)
  if ar.dtype!=DTYPE:raise ValueError('Unexpected digest shard schema')
  if not len(ar):continue
  first=np.frombuffer(ar[field].tobytes(),dtype='u1').reshape(-1,32)[:,0]
  mask=(first>>4)==bucket
  if field=='feature':mask &= ar['valid']
  if not mask.any():continue
  a=ar[mask];b=np.empty(len(a),dtype=AGG);b['sig']=a[field];b['scenario']=scenario;b['label']=a['label'];b['cls']=a['cls'];u,c=np.unique(b,return_counts=True);parts.append((u,c.astype('int64')))
  if sum(len(u) for u,c in parts)>max_records:raise MemoryError('Digest bucket exceeds bounded record limit; report partial audit, do not silently omit rows')
 if not parts:return np.empty(0,dtype=AGG),np.array([],dtype='int64')
 rows=np.concatenate([u for u,c in parts]);counts=np.concatenate([c for u,c in parts]);order=np.argsort(rows,order=AGG.names);rows=rows[order];counts=counts[order];start=np.r_[0,np.flatnonzero(rows[1:]!=rows[:-1])+1];return rows[start],np.add.reduceat(counts,start)

def overlap_stats(rows,counts):
 out={'rows':int(counts.sum()),'unique_signatures':0,'duplicate_excess':0,'multi_capture_signatures':0,'known_binary_conflict_signatures':0,'per_scenario':{},'pair_intersections':{}}
 if not len(rows):return out
 s=np.r_[0,np.flatnonzero(rows['sig'][1:]!=rows['sig'][:-1])+1];gcounts=np.add.reduceat(counts,s);bit=(np.array([1,2,4],dtype='u1')[rows['cls']]);classes=np.bitwise_or.reduceat(bit,s);scmask=np.bitwise_or.reduceat(np.left_shift(np.uint16(1),rows['scenario'].astype('uint16')-1),s)
 out.update(unique_signatures=len(s),duplicate_excess=int(np.sum(gcounts-1)),multi_capture_signatures=int(np.count_nonzero((scmask&(scmask-1))!=0)),known_binary_conflict_signatures=int(np.count_nonzero((classes&3)==3)))
 for i,j in combinations(range(1,14),2):
  n=int(np.count_nonzero(((scmask>>(i-1))&1)&((scmask>>(j-1))&1)))
  if n:out['pair_intersections'][f'{i:02d}-{j:02d}']=n
 split=(rows['sig'][1:]!=rows['sig'][:-1])|(rows['scenario'][1:]!=rows['scenario'][:-1]);q=np.r_[0,np.flatnonzero(split)+1];ends=np.r_[q[1:],len(rows)];qc=np.add.reduceat(counts,q);qbits=np.bitwise_or.reduceat(bit,q)
 for sid in np.unique(rows['scenario']):
  mask=rows['scenario'][q]==sid;out['per_scenario'][str(int(sid))]={'rows':int(qc[mask].sum()),'unique_signatures':int(mask.sum()),'duplicate_excess':int(np.sum(qc[mask]-1)),'multiple_exact_labels':int(np.count_nonzero((ends-q)[mask]>1)),'known_binary_conflict_signatures':int(np.count_nonzero((qbits[mask]&3)==3))}
 return out

def merge_overlap(parts):
 out={k:0 for k in ['rows','unique_signatures','duplicate_excess','multi_capture_signatures','known_binary_conflict_signatures']};out.update(per_scenario={},pair_intersections={})
 for p in parts:
  for k in ['rows','unique_signatures','duplicate_excess','multi_capture_signatures','known_binary_conflict_signatures']:out[k]+=p[k]
  for k,v in p['pair_intersections'].items():out['pair_intersections'][k]=out['pair_intersections'].get(k,0)+v
  for sid,rec in p['per_scenario'].items():
   dst=out['per_scenario'].setdefault(sid,{k:0 for k in rec})
   for k,v in rec.items():dst[k]+=v
 return out

def audit_overlaps(w,inventories):
 all_shards=[]
 for inv in inventories:
  sid=inv['scenario']
  for rel in inv['shards']:
   # Validate/recover each recorded shard before trusting mmap input.
   marker=rel.replace('.npy','.complete.json');w.cached(marker);all_shards.append((sid,w.local/rel))
 results={}
 for field in ['feature','event']:
  parts=[]
  for bucket in range(16):
   marker=f'overlap/{field}_{bucket:02d}.complete.json';p=w.cached(marker)
   if p is None:
    rows,counts=bucket_records(all_shards,field,bucket);p=overlap_stats(rows,counts);rel=f'overlap/{field}_{bucket:02d}.json';write(w.local/rel,p);w.finish(marker,[rel],p)
   parts.append(p);print(f'Overlap {field}: bucket {bucket+1}/16',flush=True)
  results[field]=merge_overlap(parts)
 expected_feature=sum(x['stats']['eligible_projection_rows'] for x in inventories);expected_event=sum(x['stats']['parsed_rows'] for x in inventories)
 if results['feature']['rows']!=expected_feature or results['event']['rows']!=expected_event:raise ValueError('Digest totals do not reconcile')
 results['interpretation']={'feature':'Exact canonical six-value audit projection; not original Paper 3 features and not proof of flow identity','event':'All 14 stripped source fields except label, including timestamp and endpoints; textual event identity, not independently verified packet identity','hash':'SHA-256; collisions assumed negligible, not a mathematical impossibility','unknown':'Explicit third class; not mapped to benign','multiple_exact_labels':'Not a certified count of different semantic attack families'}
 rel='overlap_summary.json';write(w.local/rel,results);w.finish('overlap.complete.json',[rel],results);return results

def run(paper3_root,registry,source,plan,local_root='/content/paper3_ctu13_inventory',chunk_rows=100000):
 w=Workspace(paper3_root,local_root,source,registry,plan,chunk_rows);inventories=[];metadata=[];errors=[];started=time.monotonic()
 for e in registry:
  sid=e['scenario'];print(f'\nScenario {sid}/13: capture {e["capture"]}',flush=True)
  try:
   m=acquire(w,e);metadata.append(m);raw=w.remote/'inputs'/f'scenario_{sid:02d}.binetflow'
   # On a fresh scan or interrupted transfer, recheck origin size/version before downloading.
   if not (w.remote/f'scenario_{sid:02d}/scan.complete.json').exists():
    current=remote_identity(e['flow_url'])
    if current!=m['remote']:raise ValueError('Origin file differs from pinned metadata')
   d=download(e['flow_url'],raw,m['remote']);local=w.local/'cache'/raw.name;local.parent.mkdir(parents=True,exist_ok=True)
   if not local.exists() or sha(local)!=d['sha256']:
    shutil.copyfile(raw,local)
    if sha(local)!=d['sha256']:raise IOError('Input local copy hash mismatch')
   inv=scan(w,e,local,d['sha256']);inventories.append(inv)
   rel=f'scenario_{sid:02d}/input_record.json';write(w.local/rel,d);w.upload(rel)
  except Exception as ex:
   errors.append({'scenario':sid,'type':type(ex).__name__,'message':str(ex)});print('Scenario blocked; keeping completed work:',errors[-1],flush=True)
  write(w.local/'progress.json',{'completed_scenarios':[x['scenario'] for x in inventories],'errors':errors})
  try:w.upload('progress.json')
  except OSError:pass
 overlap=None
 if len(inventories)==len(registry) and not errors:
  try:overlap=audit_overlaps(w,inventories)
  except Exception as ex:errors.append({'stage':'overlap','type':type(ex).__name__,'message':str(ex)})
 try:
  specimen={}
  for m in metadata:
   h=m.get('documented_binary_sha256')
   if h:specimen.setdefault(h,[]).append(m['scenario'])
  rows=[{'scenario':x['scenario'],'parsed_rows':x['stats']['parsed_rows'],'benign':x['stats']['binary_rows']['benign'],'attack':x['stats']['binary_rows']['attack'],'unknown':x['stats']['binary_rows']['unknown'],'eligible_projection_rows':x['stats']['eligible_projection_rows'],'eligible_30min_windows':x['stats']['eligible_30min_windows_at_100_per_known_class']} for x in inventories]
  rel='capture_inventory_summary.csv'
  with (w.local/rel).open('w',newline='') as f:
   writer=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['scenario']);writer.writeheader();writer.writerows(rows)
  gate={'audit_scenarios_completed':len(inventories),'requested_scenarios':len(registry),'overlap_completed':overlap is not None,'metadata_gaps':[{'scenario':m['scenario'],'missing_binary_hash':m.get('documented_binary_sha256') is None,'document_errors':{k:v['error'] for k,v in m['documents'].items() if 'error' in v}} for m in metadata if m.get('documented_binary_sha256') is None or any('error' in v for v in m['documents'].values())],'all_13_scenario_audit_complete':len(inventories)==13 and overlap is not None and not errors,'provisional_sources_meeting_4_windows':[r['scenario'] for r in rows if r['eligible_30min_windows']>=4],'same_documented_binary_groups':[{'sha256':h,'scenarios':s} for h,s in specimen.items() if len(s)>1],'shared_readme_address_mentions':[{'scenario_pair':[m['scenario'],n['scenario']],'shared_hashed_address_mentions':len(set(m.get('readme_address_mention_hashes',[]))&set(n.get('readme_address_mention_hashes',[])))} for m,n in combinations(metadata,2) if set(m.get('readme_address_mention_hashes',[]))&set(n.get('readme_address_mention_hashes',[]))],'qualified_for_original_six_field_protocol':False,'qualified_for_natural_production_prevalence':False,'qualified_for_general_warning_utility_inference':False,'reason':'Inventory only. Same institution, unresolved cross-exporter semantics and observed-label selection require a separate design review.','session_seconds':time.monotonic()-started}
  write(w.local/'gate_decision.json',gate);w.upload(rel);w.upload('gate_decision.json')
 except Exception as ex:errors.append({'stage':'final_summary','type':type(ex).__name__,'message':str(ex)})
 status='CTU13_INVENTORY_COMPLETE' if not errors and len(inventories)==13 and overlap is not None else 'CTU13_INVENTORY_PARTIAL_RESUMABLE'
 return w.report(status,errors)
