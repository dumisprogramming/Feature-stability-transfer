# CTU 13 capture inventory plan

Prepared 27 October 2026. This is a data-qualification audit after all original and S1–S18 outcomes were known. It does not train models, compute warning prediction utility, estimate natural production prevalence or certify semantic equivalence. No existing research folder is modified.

## Scope and sources

Inventory all 13 official CTU-13 scenarios, captures 42–54, using the provider's detailed-bidirectional-flow-labels standard binetflow files. Exact URLs, lengths and 4096-byte prefix hashes were preflighted during preparation; these prefix hashes are not full-file hashes. At first execution pin full-file size, ETag/Last-Modified where supplied, and compute the acquired full-file SHA-256. Changing metadata or content blocks an incompatible resume. Origin metadata and acquired checksums do not independently verify label truth or historical timestamps.

Read only flow CSVs and small README/Argus/ra configuration documents. Do not fetch executable archives, malware binaries or PCAPs. The provider's project attribution is retained in the notebook. This code does not execute external source content. It uses Python's standard library and NumPy already present in Colab. No pip operation or scientific package installation is performed.

## Data handling

Expected standard header: StartTime, Dur, Proto, SrcAddr, Sport, Dir, DstAddr, Dport, State, sTos, dTos, TotPkts, TotBytes, SrcBytes, Label.

Parse physical UTF-8 CSV lines, rejecting wrong-width, undecodable or invalid CSV lines with separate counts; no multiline CSV field support is inferred. Retain missingness and invalid numeric counts. Record every exact label and protocol. Potential primary binary mapping for inventory support only: labels starting flow=From-Botnet followed by '-' or end are attack; flow=From-Normal similarly are benign; everything else remains unknown. In particular, Background and To-Botnet are not assumed benign or malicious. This is a conservative provider-informed label convention, not independent adjudication.

Compute timestamp coverage and counts by nominal local-clock 30-minute start-time windows. Do not infer UTC from naive timestamps. The bins are feasibility summaries, not a temporal-validation experiment. A provisional source needs at least four windows with 100 eligible examples of each known class; this does not establish enough disjoint fitting/testing data or adequate statistical power.

Audit projection eligibility: TCP or UDP, destination port integer 0–65535 (decimal or 0x), finite nonnegative duration in seconds and integer total packets/total bytes/source bytes in 0–2^53−1, with source bytes <= total bytes. The duration uses the same upper bound for a finite canonical numeric domain. Other rows are retained in parsed-row inventory and event auditing, not silently discarded. Missing duration is not replaced with zero. Decimal normalization makes equivalent finite decimal strings equal; negative/NaN/infinite values are ineligible. Missing durations or port encoding do not turn unknown labels into known labels.

Duration summaries cover valid duration values in all parsed rows, separately from projection eligibility, and include count, sum, min/max, zero count and fixed histogram bins. No quantile or representative prevalence claim is made from a prefix or selected subset.

## Overlap definitions

Projection signature: SHA-256 of JSON [lowercase protocol, canonical destination port, canonical duration, total packets, total bytes, source bytes]. This is a NEW audit projection. It is neither the original 49 NetFlow-v3 predictors nor the S16–S18 six directional fields. A matching projection is not proof of matching flows or leakage.

Textual event signature: SHA-256 of JSON containing all 14 stripped source fields except Label, retaining timestamp, endpoints, port spellings and numeric spellings. This measures exact textual event repetition after edge whitespace stripping. It is not independently verified packet identity and need not detect all semantically equivalent flows.

For each definition report total occurrences, unique signatures, duplicate excess, signatures shared across scenarios, all pairwise signature intersections, known-class conflicts, and within-scenario multi-exact-label signatures. Multi-label signatures are not certified different malware families. Unknown membership is explicit. SHA-256 collisions are assumed negligible, not impossible.

Store per-row hashes with exact-label indices, class code and eligibility in ordered NPY chunks. No raw endpoint values occur in these digest arrays. Compare all scenario pairs through 16 disjoint first-nibble hash buckets. Reduce each chunk before merging; cap a bucket at five million reduced records. If the bound is exceeded, emit a partial report rather than silently dropping rows. All aggregate occurrence totals must reconcile with the inventory.

Extract probable malware name and specimen SHA-256 from provider READMEs. Same recorded hash is a provider-provenance link, not verification of the executable or behavioural equivalence. Record shared hashed IP mentions in README text as a diagnostic only; those mentions are not necessarily independent infected hosts. Repeated scenarios from CTU remain clustered within one institution.

## Persistence and resume

Root: Paper3_DataSet/supplementary_ctu13_inventory_20261027/run_v1 under the existing NIDS_Research Drive tree. Download raw inputs to a separate inputs directory, resuming .part files with validated HTTP byte ranges. A server returning whole-file status 200 for a nonzero resume range is rejected. Raw full inputs are rehashed before reuse. Copy to local Colab cache before scanning.

Checkpoint each 100,000 physical data lines, preserving input full hash, byte offset, counters, label order and hash-shard checksum. Write outputs before their completion markers. A crash may require repeating the current uncommitted chunk but not preceding committed chunks. A fresh local runtime copies verified remote chunks back before overlap analysis. Checkpoint each overlap bucket. Resume identity locks code, registry, plan, chunk size, exact Python and NumPy versions. Use the same notebook without editing; incompatible environments fail explicitly rather than mix results.

Integrity checksums detect changed recorded files, not deliberate rewriting of both results and checksums. Interrupted scans and downloads were tested on synthetic fixtures. No complete CTU empirical audit was run during preparation.

## Outputs and stop rules

Complete status: CTU13_INVENTORY_COMPLETE, only when all 13 flow inventories and both overlap audits finish without execution errors. Any incomplete scenario or overlap gives CTU13_INVENTORY_PARTIAL_RESUMABLE. Metadata gaps are listed separately even when flow inventory is complete. The gate decision always leaves original-six-field compatibility, natural production prevalence and general warning inference unqualified: those require separate scientific review.

Compact report ZIP: code, plan, registry, software identity, per-scenario metadata/inventory, input records, chunk completion records, overlap bucket summaries, aggregate overlap, CSV summary, gate decision, progress/errors and file hashes. Raw CSVs, per-row digest arrays and full source documentation text are excluded. References to omitted checkpoint outputs are therefore expected. The verifier checks included hashes and arithmetic but cannot replay omitted row hashes or original data.

On Drive failure retain the local report when possible. Restore the Drive connection and rerun the unchanged notebook. Do not delete checkpoints to resolve a transport error. Do not claim completion from a partial report. Exact runtime is unknown before actual execution; approximately 2.73 GB of raw acquisition and additional hashing/sorting are involved. Allow ample Drive and local disk space; 8 GB free in each is a practical starting recommendation, not an audited upper bound.

## Provider references

https://www.stratosphereips.org/datasets-ctu13

Garcia S, Grill M, Stiborek J, Zunino A. An empirical comparison of botnet detection methods. Computers & Security. 2014;45:100–123. https://doi.org/10.1016/j.cose.2014.05.011

Official per-capture files: https://mcfp.felk.cvut.cz/publicDatasets/CTU-Malware-Capture-Botnet-42/ through CTU-Malware-Capture-Botnet-54/.
