"""Fixed, post hoc, dataset-role-excluded prediction comparisons."""
from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
from sklearn.linear_model import LinearRegression
KEY=['source_dataset','seed','model']
WARN=['sampling_instability','environmental_instability','sampling_environment_gap']
BASE_SPECS={'mean_only':[],'model_only':[],'model_plus_sampling':WARN[:1],
 'model_plus_environment':WARN[1:2],'model_plus_gap':WARN[2:],
 'model_plus_both_primary':WARN[1:]}
def analyse(f,out,extra_specs=None):
 out=Path(out);out.mkdir(parents=True,exist_ok=True)
 specs={**BASE_SPECS,**(extra_specs or {})};cols=list(dict.fromkeys(c for v in specs.values() for c in v))
 if len(f)!=180 or f.duplicated(KEY+['target_dataset']).any():raise ValueError('Expected complete unique 180-job input')
 if not np.isfinite(f[cols+['balanced_accuracy_loss']].to_numpy()).all():raise ValueError('Nonfinite analysis input')
 if not f.groupby(KEY)[cols].nunique().eq(1).all().all():raise ValueError('Source indicators change with target')
 def aggregate(a):return a.groupby(KEY,as_index=False).agg(loss=('balanced_accuracy_loss','mean'),**{c:(c,'first') for c in cols})
 def design(t,e,cs,name):
  a=[np.ones(len(t))];b=[np.ones(len(e))]
  if name!='mean_only':
   for m in ['RandomForest','XGBoost']:a.append(t.model.eq(m).to_numpy(float));b.append(e.model.eq(m).to_numpy(float))
  for c in cs:
   mu=t[c].mean();sd=t[c].std(ddof=0);sd=sd if sd>0 else 1.
   a.append((t[c].to_numpy()-mu)/sd);b.append((e[c].to_numpy()-mu)/sd)
  return np.column_stack(a),np.column_stack(b)
 predictions=[];diagnostics=[]
 for omit in [None]+list(range(2027,2032)):
  sub=f if omit is None else f[f.seed!=omit];run='all_seeds' if omit is None else 'omit_seed:'+str(omit)
  for held in sorted(sub.source_dataset.unique()):
   train=sub[(sub.source_dataset!=held)&(sub.target_dataset!=held)];test=sub[sub.source_dataset==held]
   if held in set(train.source_dataset)|set(train.target_dataset):raise ValueError('Held-out dataset role leakage')
   if not train.groupby(KEY).target_dataset.nunique().eq(2).all() or not test.groupby(KEY).target_dataset.nunique().eq(3).all():raise ValueError('Unexpected target counts')
   t,e=aggregate(train),aggregate(test)
   changed=sub.copy();changed.loc[(changed.source_dataset==held)|(changed.target_dataset==held),'balanced_accuracy_loss']+=1000
   pd.testing.assert_frame_equal(t,aggregate(changed[(changed.source_dataset!=held)&(changed.target_dataset!=held)]))
   for name,cs in specs.items():
    a,b=design(t,e,cs,name);mut=e.copy()
    for c in cs:mut[c]+=1000
    if not np.array_equal(a,design(t,mut,cs,name)[0]):raise ValueError('Test values changed training scaling')
    coef=np.linalg.lstsq(a,t.loss,rcond=None)[0];prediction=b@coef
    independent=LinearRegression(fit_intercept=False).fit(a,t.loss).predict(b)
    diff=float(np.max(np.abs(prediction-independent)));rank=int(np.linalg.matrix_rank(a))
    if diff>1e-10 or rank!=a.shape[1]:raise ValueError('Independent fit/rank check failed')
    diagnostics.append({'run':run,'held_out':held,'specification':name,'training_units':len(t),'test_units':len(e),'rank':rank,'columns':a.shape[1],'maximum_independent_difference':diff})
    for (_,r),v in zip(e.iterrows(),prediction):predictions.append({'run':run,'held_out':held,'source_dataset':held,'seed':int(r.seed),'model':r.model,'specification':name,'actual_loss':float(r.loss),'predicted_loss':float(v)})
 pred=pd.DataFrame(predictions);rows=[]
 for level,keys in [('overall',['run','specification']),('fold',['run','held_out','specification'])]:
  for key,g in pred.groupby(keys):
   er=g.actual_loss-g.predicted_loss;rows.append({**dict(zip(keys,key)),'level':level,'units':len(g),'mae':float(abs(er).mean()),'rmse':float(np.sqrt((er**2).mean()))})
 sc=pd.DataFrame(rows).fillna('ALL');scope=['run','level','held_out'];ref=sc[sc.specification=='model_only'].set_index(scope).mae
 sc['mae_improvement_vs_model_only']=[float(ref.loc[tuple(r[k] for k in scope)])-r.mae for _,r in sc.iterrows()]
 unit=aggregate(f).groupby(['source_dataset','model'],as_index=False)[['loss']+cols].mean()
 associations=[{'indicator':c,'units':len(unit),'spearman_rho':float(unit[c].rank().corr(unit.loss.rank())),'inference':'descriptive_only'} for c in cols]
 f.to_csv(out/'transfer_input_180.csv',index=False);pred.to_csv(out/'predictions.csv',index=False);sc.to_csv(out/'scores.csv',index=False)
 for name,value in [('design_diagnostics.json',diagnostics),('descriptive_associations.json',associations)]:
  (out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
 return {'status':'PASS','fits':len(diagnostics),'predictions':len(pred),'maximum_independent_difference':max(x['maximum_independent_difference'] for x in diagnostics),'no_new_detector_training':True},sc

"""New source-model cross-validation and full-raw temporal eligibility audit."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json,hashlib,shutil,zipfile,time,warnings,platform,gc
import numpy as np,pandas as pd,joblib,sklearn
from sklearn.base import clone
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.metrics import roc_curve,balanced_accuracy_score
DATASETS=['NF_BoT_IoT_v3','NF_CSE_CIC_IDS2018_v3','NF_ToN_IoT_v3','NF_UNSW_NB15_v3']
LOCAL_BASE=Path('/content')
MODELS=['LogisticRegression','RandomForest','XGBoost'];SEEDS=list(range(2027,2032));META={'row_id','Label','block_id_ms','pseudo_environment_id','actual_environment_id'}
CV_PLAN='''Post hoc five-fold source cross-validation plan before new fitting. Earlier results are known.
Use only each original source training partition for five stratified, exact-feature-group-disjoint folds. All classifiers share the split within a dataset/seed. Keep identical cleaned 49-feature signatures together. Fit a new median imputer inside each training fold and a new standard scaler only for logistic regression. Clone the exact saved estimator's hyperparameters, retaining its source seed; never reuse fitted weights. Fit 4/5 of the original source training rows. Calibrate the new fitted model's threshold using the original, disjoint source calibration partition and the original BA/tie-break rule. Do not fit preprocessing on calibration or validation rows. Score the held-out training fold with the calibrated threshold. This is a source-only estimator of fold performance variability with shared calibration, not a variance estimate over independent datasets. Retain all five BA scores, population SD and mean for 60 source/model/seed units (300 refits). Stop on convergence warnings. Preserve fold prediction records and check exact row/feature-group exclusion and confusion counts. New models do not replace any historical source model.
Before reading target outcomes for meta-regression, save the 60 new SD controls with a checksum. Compare model identity, both primary warnings and sampling instability with the six original specifications plus model+CV SD and model+CV SD+both primary warnings, using strict exclusion of the held-out dataset from both training roles. Run both original balanced and new unstratified target outcomes, including all five seed deletions. All estimates are post hoc descriptive results; no new significance or equivalence claims. Check training-only regression scaling and independent least-squares predictions. Checkpoint each complete fold and resume only with identical code/configuration/software/input hashes. Originals remain read only.
'''
TEMP_PLAN='''Post hoc feasibility audit before fresh temporal importance experiments. Earlier study outcomes are known.
Scan all four complete original raw CSVs with the fixed 49 features, Label and FLOW_START_MILLISECONDS, retaining original parsed row IDs. Verify pinned archive hashes and complete raw class/row counts. For every dataset and original seed, remove exact cleaned feature signatures matching original source training, calibration or source-test rows. Original environment rows are allowed, because no detector or calibration preprocessing was fitted on them; a later fresh deterministic draw may overlap them and must report this. Count remaining benign/attack flows in every UTC-aligned 3/6/12/24-hour window. A window is eligible at the historical quota of at least 2,000 per class. Retain every observed window, counts before and after exclusion, excluded-row counts and all seed/width summaries. At least two eligible groups are necessary for a stability comparison. Do not shrink quotas, select only favourable widths or present regrouping as fresh sampling. This audit runs no permutation importance, new detector fitting, warning regression or new target prediction. If any combination is unsupported, report it explicitly rather than silently alter the design. Once returned, these audited counts determine whether the prespecified fresh-sampling experiment is feasible; completion of this audit is not completion of that experiment.
'''
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
def js(p):return json.loads(Path(p).read_text())
def write(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n');q.replace(p)
def keys(f,features):
 a=f[features].to_numpy(np.float64,copy=True);a[~np.isfinite(a)]=np.nan;a[a==0]=0.;a[np.isnan(a)]=np.nan
 return np.ascontiguousarray(a.astype('<f8',copy=False)).view(np.dtype((np.void,8*len(features)))).ravel().copy()
def clean(f,features):return f[features].astype(np.float64).replace([np.inf,-np.inf],np.nan).to_numpy(np.float32)
def threshold(y,p):
 fpr,tpr,th=roc_curve(y,p,drop_intermediate=False);valid=np.isfinite(th)&(th>=0)&(th<=1);th=th[valid];ba=(tpr[valid]+1-fpr[valid])/2
 ix=np.flatnonzero(np.isclose(ba,ba.max(),rtol=0,atol=1e-12));return float(th[ix[np.argmin(np.abs(th[ix]-.5))]])
def confusion(y,pred):
 tn,fp,fn,tp=map(int,np.bincount(2*np.asarray(y,int)+np.asarray(pred,int),minlength=4))
 if min(tn+fp,fn+tp)<=0:raise ValueError('Both classes required')
 return {'tn':tn,'fp':fp,'fn':fn,'tp':tp,'balanced_accuracy':.5*(tn/(tn+fp)+tp/(tp+fn))}
def fold_assignments(frame,features,seed):
 y=frame.Label.to_numpy(np.int8);_,groups=np.unique(keys(frame,features),return_inverse=True)
 splitter=StratifiedGroupKFold(n_splits=5,shuffle=True,random_state=seed);folds=np.full(len(y),-1,int)
 for fold,(tr,va) in enumerate(splitter.split(np.zeros(len(y)),y,groups)):
  if np.intersect1d(groups[tr],groups[va]).size or len(np.unique(y[va]))!=2 or len(np.unique(y[tr]))!=2:raise ValueError('Invalid grouped fold')
  folds[va]=fold
 if (folds<0).any():raise ValueError('Unassigned source training rows')
 return folds,groups

class Workspace:
 def __init__(self,root,stage,plan,source):
  import scipy,pyarrow,xgboost
  self.root=Path(root);self.local=LOCAL_BASE/stage/'run_v1';self.remote=self.root/stage/'run_v1';self.cache=LOCAL_BASE/'paper3_remaining_input_cache'
  self.local.mkdir(parents=True,exist_ok=True);self.cache.mkdir(parents=True,exist_ok=True)
  self.identity={'stage':stage,'plan_sha256':hashlib.sha256(plan.encode()).hexdigest(),'code_sha256':hashlib.sha256(source.encode()).hexdigest(),
   'outcomes_sha256':hashlib.sha256(json.dumps(OUTCOME_RECORDS,sort_keys=True).encode()).hexdigest(),
   'pins_sha256':hashlib.sha256(json.dumps(PINS,sort_keys=True).encode()).hexdigest(),'raw_info_sha256':hashlib.sha256(json.dumps(RAW_INFO,sort_keys=True).encode()).hexdigest(),
   'software':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__,'scipy':scipy.__version__,'xgboost':xgboost.__version__,'pyarrow':pyarrow.__version__,'joblib':joblib.__version__}}
  (self.local/'PLAN.md').write_text(plan);(self.local/'EXPERIMENT_CODE.py').write_text(source);write(self.local/'PINNED_INPUTS.json',PINS);write(self.local/'OUTCOME_RECORDS.json',OUTCOME_RECORDS)
 def setup(self):
  if self.identity['software']['sklearn']!='1.6.1' or self.identity['software']['xgboost']!='3.4.1':raise ValueError('Restart and run the dependency cell; required original model versions differ')
  old=self.restore('run_identity.json')
  if old.exists() and js(old)!=self.identity:raise ValueError('Existing run code/software/inputs differ; do not overwrite it')
  write(old,self.identity)
  for n in ['run_identity.json','PLAN.md','EXPERIMENT_CODE.py','PINNED_INPUTS.json','OUTCOME_RECORDS.json']:self.upload(n)
 def upload(self,rel):
  a=self.local/rel;b=self.remote/rel;b.parent.mkdir(parents=True,exist_ok=True);tmp=b.with_suffix(b.suffix+'.tmp');shutil.copyfile(a,tmp)
  if sha(a)!=sha(tmp):raise IOError('Drive copy checksum differs')
  tmp.replace(b)
 def restore(self,rel):
  a=self.local/rel;b=self.remote/rel
  if not a.exists() and b.is_file():a.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(b,a)
  return a
 def stage(self,rel):
  expected=PINS.get(str(rel))
  if not expected:raise ValueError('Historical file has no pinned checksum: '+str(rel))
  a=self.cache/rel
  if a.is_file() and sha(a)==expected:return a
  a.parent.mkdir(parents=True,exist_ok=True);tmp=a.with_suffix(a.suffix+'.tmp');shutil.copyfile(self.root/rel,tmp)
  if sha(tmp)!=expected:raise ValueError('Input checksum differs: '+str(rel))
  tmp.replace(a);return a
 def cached(self,rel):
  a=self.restore(rel)
  if not a.exists():return None
  r=js(a)
  if r['identity']!=self.identity:raise ValueError('Checkpoint identity differs')
  for name,h in r['outputs'].items():
   p=self.restore(name)
   if not p.is_file() or sha(p)!=h:raise ValueError('Checkpoint output differs: '+name)
  return r['details']
 def finish(self,rel,files,details):
  write(self.local/rel,{'identity':self.identity,'outputs':{n:sha(self.local/n) for n in files},'details':details})
  for n in files:self.upload(n)
  self.upload(rel)
 def package(self,report):
  write(self.local/'verification_summary.json',report)
  included=[p for p in self.local.rglob('*') if p.is_file() and p.suffix not in ['.zip','.parquet'] and not p.name.endswith('.tmp') and p.name!='report_hashes.json']
  write(self.local/'report_hashes.json',{str(p.relative_to(self.local)):sha(p) for p in included})
  included.append(self.local/'report_hashes.json')
  output=self.local/(self.identity['stage']+'_report_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')+'.zip')
  with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED) as z:
   for p in included:z.write(p,str(p.relative_to(self.local)))
  try:
   self.upload('verification_summary.json');self.upload('report_hashes.json');shutil.copyfile(output,self.remote/output.name)
   print('Drive folder:',self.remote)
  except Exception as err:print('Drive unavailable; keep runtime and download local report:',type(err).__name__,str(err))
  print('Status:',report['status'],'Local ZIP:',output);return output

def run_cv(root,source):
 w=Workspace(root,'supplementary_source_cv_20261024',CV_PLAN,source);report={'status':'RUNNING','folds_completed':0,'started_utc':datetime.now(timezone.utc).isoformat()}
 try:
  w.setup();features=js(w.stage('Paper3_Materialized/feature_schema_v1.json'))['predictors_in_order'];allfolds=[];summaries=[]
  for ds in DATASETS:
   for seed in SEEDS:
    base=f'Paper3_Sanitized/{ds}/seed_{seed}';frame=pd.read_parquet(w.stage(base+'/train.parquet'));cal=pd.read_parquet(w.stage(base+'/calibration.parquet'))
    if len(features)!=49 or [c for c in frame.columns if c not in META]!=features:raise ValueError('Source feature order differs')
    if np.intersect1d(keys(frame,features),keys(cal,features)).size:raise ValueError('Source training/calibration overlap')
    folds,groups=fold_assignments(frame,features,seed)
    assignment=pd.DataFrame({'row_id':frame.row_id,'fold':folds,'signature_group':groups})
    folder=f'folds/{ds}/seed_{seed}';(w.local/folder).mkdir(parents=True,exist_ok=True)
    assignment.to_csv(w.local/folder/'assignments.csv',index=False);assignment_sha=sha(w.local/folder/'assignments.csv')
    for name in MODELS:
     original=joblib.load(w.stage(f'Paper3_Source_Models/{ds}/seed_{seed}/{name}_model.joblib'))
     if original['dataset']!=ds or int(original['seed'])!=seed or original['model_name']!=name or list(original['features'])!=features:raise ValueError('Model identity mismatch')
     if bool(original['uses_standard_scaler'])!=(name=='LogisticRegression'):raise ValueError('Model scaler mismatch')
     records=[]
     for fold in range(5):
      marker=f'{folder}/{name}_fold_{fold}.json';cached=w.cached(marker)
      if cached is not None:
       if cached['assignment_sha256']!=assignment_sha:raise ValueError('Fold assignment changed')
       records.append(cached);allfolds.append(cached);report['folds_completed']=len(allfolds);print('Reused',len(allfolds),'/300',ds,seed,name,fold,flush=True);continue
      start=time.monotonic();tr=np.flatnonzero(folds!=fold);va=np.flatnonzero(folds==fold)
      imputer=SimpleImputer(strategy='median');xtr=imputer.fit_transform(clean(frame.iloc[tr],features)).astype(np.float32)
      xc=imputer.transform(clean(cal,features)).astype(np.float32);xv=imputer.transform(clean(frame.iloc[va],features)).astype(np.float32)
      if name=='LogisticRegression':
       scaler=StandardScaler();xtr=scaler.fit_transform(xtr).astype(np.float32);xc=scaler.transform(xc).astype(np.float32);xv=scaler.transform(xv).astype(np.float32)
      if xtr.shape[1]!=49 or not all(np.isfinite(x).all() for x in [xtr,xc,xv]):raise ValueError('Invalid transformed fold features')
      est=clone(original['model'])
      with warnings.catch_warnings(record=True) as warns:
       warnings.simplefilter('always');est.fit(xtr,frame.Label.iloc[tr].to_numpy(np.int8))
      if any(issubclass(q.category,sklearn.exceptions.ConvergenceWarning) for q in warns):raise ValueError('Fold convergence warning; do not omit the fold')
      cp=est.predict_proba(xc)[:,1];prob=est.predict_proba(xv)[:,1]
      if not all(np.isfinite(q).all() and ((q>=0)&(q<=1)).all() for q in [cp,prob]):raise ValueError('Invalid fold probabilities')
      th=threshold(cal.Label.to_numpy(np.int8),cp);yp=(prob>=th).astype(np.int8);truth=frame.Label.iloc[va].to_numpy(np.int8)
      count=confusion(truth,yp)
      if abs(count['balanced_accuracy']-balanced_accuracy_score(truth,yp))>1e-12:raise ValueError('Independent fold BA differs')
      rel=f'{folder}/{name}_fold_{fold}_predictions.parquet';pd.DataFrame({'row_id':frame.row_id.iloc[va].to_numpy(),'y_true':truth,'probability_attack':prob,'y_pred':yp}).to_parquet(w.local/rel,index=False)
      record={'source_dataset':ds,'seed':seed,'model':name,'fold':fold,'training_rows':len(tr),'validation_rows':len(va),'calibration_rows':len(cal),'threshold':th,'assignment_sha256':assignment_sha,'validation_group_overlap':0,'training_row_ids_sha256':hashlib.sha256(frame.row_id.iloc[tr].to_numpy('<i8').tobytes()).hexdigest(),'validation_row_ids_sha256':hashlib.sha256(frame.row_id.iloc[va].to_numpy('<i8').tobytes()).hexdigest(),'elapsed_seconds':time.monotonic()-start,'warnings':[str(q.message) for q in warns],**count}
      w.finish(marker,[f'{folder}/assignments.csv',rel],record);records.append(record);allfolds.append(record);report['folds_completed']=len(allfolds)
      write(w.local/'progress.json',report);print('Completed',len(allfolds),'/300',ds,seed,name,'fold',fold,flush=True)
      del est,xtr,xc,xv,cp,prob;gc.collect()
     values=np.array([q['balanced_accuracy'] for q in records]);summaries.append({'source_dataset':ds,'seed':seed,'model':name,'source_cv_ba_sd':float(values.std(ddof=0)),'source_cv_ba_mean':float(values.mean()),'folds':5})
    del frame,cal,original;gc.collect()
  if len(allfolds)!=300 or len(summaries)!=60:raise ValueError('Incomplete CV grid')
  pd.DataFrame(allfolds).to_csv(w.local/'fold_scores_300.csv',index=False);pd.DataFrame(summaries).to_csv(w.local/'source_cv_controls_60.csv',index=False)
  write(w.local/'source_cv_record.json',{'sha256':sha(w.local/'source_cv_controls_60.csv'),'saved_before_new_meta_regression':True,'post_hoc':True})
  for n in ['fold_scores_300.csv','source_cv_controls_60.csv','source_cv_record.json']:w.upload(n)
  # Embedded fixed-outcome records are hashes checked at notebook construction.
  extra={'model_plus_cv_sd':['source_cv_ba_sd'],'model_plus_cv_sd_and_primary':['source_cv_ba_sd','environmental_instability','sampling_environment_gap']}
  for label,records in OUTCOME_RECORDS.items():
   transfer=pd.DataFrame(records).merge(pd.DataFrame(summaries),on=['source_dataset','seed','model'],validate='many_to_one')
   checked,scores=analyse(transfer,w.local/('analysis_'+label),extra);print(label,scores[(scores.run=='all_seeds')&(scores.level=='overall')].to_string(index=False))
   for p in (w.local/('analysis_'+label)).rglob('*'):
    if p.is_file():w.upload(str(p.relative_to(w.local)))
  report.update(status='PASS',source_units=60,new_refitted_models=300,shared_calibration_across_folds=True,completed_utc=datetime.now(timezone.utc).isoformat())
 except Exception as e:report.update(status='INCOMPLETE',error_type=type(e).__name__,error=str(e));print('STOPPED',type(e).__name__,str(e),flush=True)
 return w.package(report)

def run_temporal_audit(root,source):
 w=Workspace(root,'supplementary_fresh_temporal_feasibility_20261024',TEMP_PLAN,source);report={'status':'RUNNING','completed_datasets':0,'new_warning_experiment_completed':False,'started_utc':datetime.now(timezone.utc).isoformat()};summaries=[]
 try:
  w.setup();features=js(w.stage('Paper3_Materialized/feature_schema_v1.json'))['predictors_in_order']
  for ds in DATASETS:
   marker=f'audit/{ds}/complete.json';old=w.cached(marker)
   if old is not None:summaries+=old['summaries'];report['completed_datasets']+=1;print('Reused complete temporal audit:',ds,flush=True);continue
   source_keys={}
   for seed in SEEDS:
    parts=[keys(pd.read_parquet(w.stage(f'Paper3_Sanitized/{ds}/seed_{seed}/{split}.parquet')),features) for split in ['train','calibration','source_test']]
    source_keys[seed]=np.unique(np.concatenate(parts))
   raw=RAW_INFO[ds];archive=w.stage(raw['raw_zip_name']);offset=0;counts=Counter();remaining={s:Counter() for s in SEEDS};rawcounts=Counter();excluded=Counter();invalid_ts=0
   with zipfile.ZipFile(archive) as z:
    with z.open(raw['raw_csv_member']) as stream:
     for ci,chunk in enumerate(pd.read_csv(stream,usecols=features+['Label','FLOW_START_MILLISECONDS'],chunksize=100000,low_memory=False),1):
      lab=pd.to_numeric(chunk.Label,errors='coerce').to_numpy();ts=pd.to_numeric(chunk.FLOW_START_MILLISECONDS,errors='coerce').to_numpy(float)
      if not np.isin(lab,[0,1]).all():raise ValueError('Invalid raw binary label')
      rawcounts.update({str(k):int((lab==k).sum()) for k in [0,1]});good=np.isfinite(ts)&(ts>=0)&(ts<9e18)&(ts==np.floor(ts));invalid_ts+=int((~good).sum())
      signatures=keys(chunk,features);masks={s:good&~np.isin(signatures,source_keys[s]) for s in SEEDS}
      for seed in SEEDS:excluded[seed]+=int((good&~masks[seed]).sum())
      for hours in [3,6,12,24]:
       width=hours*3600000;blocks=(ts[good].astype(np.int64)//width)*width;y=lab[good].astype(int)
       for (block,label),n in pd.DataFrame({'b':blocks,'y':y}).groupby(['b','y']).size().items():counts[(hours,int(block),int(label))]+=int(n)
       for seed in SEEDS:
        block=(ts[masks[seed]].astype(np.int64)//width)*width
        for (b,label),n in pd.DataFrame({'b':block,'y':lab[masks[seed]].astype(int)}).groupby(['b','y']).size().items():remaining[seed][(hours,int(b),int(label))]+=int(n)
      offset+=len(chunk);write(w.local/'progress.json',{'dataset':ds,'rows_scanned':offset,'completed_datasets':report['completed_datasets']})
      if ci%10==0:print(ds,format(offset,','),'raw rows audited',flush=True)
   if offset!=raw['raw_rows'] or dict(rawcounts)!=raw['raw_class_counts'] or invalid_ts:raise ValueError('Full raw counts/timestamps differ from expected metadata')
   rows=[];ds_summary=[]
   for seed in SEEDS:
    for hours in [3,6,12,24]:
     starts=sorted({b for h,b,y in counts if h==hours});eligible=0
     for b in starts:
      benign=remaining[seed][hours,b,0];attack=remaining[seed][hours,b,1];ok=min(benign,attack)>=2000;eligible+=int(ok)
      rows.append({'dataset':ds,'seed':seed,'hours':hours,'block_start_ms':b,'raw_benign':counts[hours,b,0],'raw_attack':counts[hours,b,1],'remaining_benign':benign,'remaining_attack':attack,'eligible_at_2000_each_class':ok})
     record={'dataset':ds,'seed':seed,'hours':hours,'observed_windows':len(starts),'eligible_windows':eligible,'minimum_groups_for_stability':2,'feasible':eligible>=2,'raw_rows_excluded_by_source_signatures':excluded[seed]};ds_summary.append(record)
   folder=w.local/'audit'/ds;folder.mkdir(parents=True,exist_ok=True);rel=f'audit/{ds}/window_counts.csv';pd.DataFrame(rows).to_csv(w.local/rel,index=False)
   w.finish(marker,[rel],{'raw_rows':offset,'class_counts':dict(rawcounts),'invalid_timestamps':invalid_ts,'summaries':ds_summary});summaries+=ds_summary;report['completed_datasets']+=1;del source_keys;gc.collect()
  frame=pd.DataFrame(summaries);frame.to_csv(w.local/'temporal_feasibility_80.csv',index=False);w.upload('temporal_feasibility_80.csv')
  if len(frame)!=80:raise ValueError('Expected all 80 dataset/seed/width combinations')
  report.update(status='AUDIT_COMPLETED',feasible_combinations=int(frame.feasible.sum()),infeasible_combinations=int((~frame.feasible).sum()),full_fresh_sampling_experiment_completed=False,completed_utc=datetime.now(timezone.utc).isoformat())
  print(frame.to_string(index=False))
 except Exception as e:report.update(status='INCOMPLETE',error_type=type(e).__name__,error=str(e));print('STOPPED',type(e).__name__,str(e),flush=True)
 return w.package(report)

"""Fresh raw-flow temporal sensitivity; post hoc, original fitted detectors fixed."""
import itertools
from sklearn.inspection import permutation_importance
FRESH_STAGE='supplementary_fresh_temporal_importance_20261024'
HOURS=[3,6,12,24]
QUOTA=2000
FRESH_PLAN='''Post hoc fresh temporal sampling plan. Earlier target outcomes and feasibility results are known. All four original sources, five seeds, three frozen classifiers and all UTC widths 3,6,12,24 hours are retained. Use every eligible window from the returned pinned feasibility audit, at 2000 benign and 2000 attack flows each. Exclude exact canonical 49-feature signatures matching same-seed historical training/calibration/source-test. Historical environmental rows are allowed; report row and signature overlap. No smaller quotas, selected widths, new detector fitting or target adaptation. Scan complete raw archives, validate all row/class counts and per-window post-exclusion counts against the audit. Deterministic SplitMix64 priorities keyed by dataset/seed/width choose bottom-k parsed raw row IDs separately in each eligible window and class. This is a new draw, not regrouping historical environmental rows. Repeated feature signatures within/between new groups are retained and their cross-group multiplicity is reported; no independence claim follows.
Construct matched pseudo-groups from exactly the selected rows, preserving group sizes and binary class counts, using fixed seeded random permutations within each class. Fixed historical preprocessing and calibrated thresholds apply to all groups. Before new importance, reproduce each original source-test probability and decision. For every actual/pseudo group use sklearn permutation importance with BA at the fixed threshold, 49 features and three repeats, n_jobs=1. Average repeats per feature; compute mean pairwise Spearman using average ranks, with undefined constant-rank correlations assigned zero and counted. Sampling instability=1-sampling stability; environmental instability=1-environmental stability; gap=sampling stability-environmental stability. Save all 240 warning units before new post hoc regression calculations. Run the original six fixed warning specifications at every width on both original balanced and unstratified target outcomes, strict exclusion of held-out dataset from source and target training roles, training-only scaling, no tuning/clipping, all five seed deletions. No new significance or equivalence tests. Counts/quotas, widths, fixed seeds and failed jobs are not silently changed. Checkpoint sampling per dataset and importance per group to local disk then Drive, with identity and checksums; a complete marker is written only after outputs. Original data, models, warnings and confirmatory outputs remain unchanged. All new analyses are sensitivity evidence on the same captures, not independent replication or a controlled isolation of width alone because sample memberships also change. UNSW at24h has only two groups.
'''
def state(*parts):return int.from_bytes(hashlib.sha256('|'.join(map(str,parts)).encode()).digest()[:4],'little')
def priority(ids,salt):
 # Bijective uint64 mixing: row IDs have unique priorities, independent of chunks/order.
 with np.errstate(over='ignore'):
  z=np.asarray(ids,dtype=np.uint64)+np.uint64(salt)+np.uint64(0x9E3779B97F4A7C15)
  z=(z^(z>>np.uint64(30)))*np.uint64(0xBF58476D1CE4E5B9)
  z=(z^(z>>np.uint64(27)))*np.uint64(0x94D049BB133111EB)
  return z^(z>>np.uint64(31))
def retain(old,new):
 f=new if old is None else pd.concat([old,new],ignore_index=True)
 if len(f)>QUOTA:f=f.iloc[np.argpartition(f._priority.to_numpy(np.uint64),QUOTA-1)[:QUOTA]].copy()
 return f

def fresh_sample(w,ds,features):
 marker=f'samples/{ds}/complete.json';old=w.cached(marker)
 if old is not None:return old
 audit=pd.read_csv(w.stage(f'supplementary_fresh_temporal_feasibility_20261024/run_v1/audit/{ds}/window_counts.csv'))
 source={};historical={};buffers={};remaining=Counter();rawcounts=Counter();offset=0
 expected={}
 for seed in SEEDS:
  source[seed]=np.unique(np.concatenate([keys(pd.read_parquet(w.stage(f'Paper3_Sanitized/{ds}/seed_{seed}/{split}.parquet')),features) for split in ['train','calibration','source_test']]))
  historical[seed]=pd.read_parquet(w.stage(f'Paper3_Sanitized/{ds}/seed_{seed}/environment.parquet'))
  for h in HOURS:
   group=audit[(audit.seed==seed)&(audit.hours==h)]
   for row in group.itertuples():expected[seed,h,int(row.block_start_ms)]=(int(row.remaining_benign),int(row.remaining_attack),bool(row.eligible_at_2000_each_class))
   if int(group.eligible_at_2000_each_class.sum())<2:raise ValueError('Unsupported audited combination; do not shrink quota')
 raw=RAW_INFO[ds]
 with zipfile.ZipFile(w.stage(raw['raw_zip_name'])) as z,z.open(raw['raw_csv_member']) as stream:
  for ci,chunk in enumerate(pd.read_csv(stream,usecols=features+['Label','FLOW_START_MILLISECONDS'],chunksize=100000,low_memory=False),1):
   labels=pd.to_numeric(chunk.Label,errors='coerce').to_numpy();ts=pd.to_numeric(chunk.FLOW_START_MILLISECONDS,errors='coerce').to_numpy(float)
   if not np.isin(labels,[0,1]).all() or not (np.isfinite(ts)&(ts>=0)&(ts<9e18)&(ts==np.floor(ts))).all():raise ValueError('Invalid raw label/time')
   rawcounts.update({str(k):int((labels==k).sum()) for k in [0,1]});sig=keys(chunk,features);rowids=np.arange(offset,offset+len(chunk),dtype=np.int64)
   for seed in SEEDS:
    allowed=~np.isin(sig,source[seed])
    for h in HOURS:
     width=h*3600000;blocks=ts.astype(np.int64)//width*width
     for b in np.unique(blocks):
      for label in [0,1]:
       ix=np.flatnonzero(allowed&(blocks==b)&(labels==label));remaining[seed,h,int(b),label]+=len(ix)
       exp=expected.get((seed,h,int(b)))
       if exp is None:raise ValueError('Raw window absent from pinned audit')
       if not exp[2] or not len(ix):continue
       k=(seed,h,int(b),label);scores=priority(rowids[ix],state('FRESH_TEMPORAL_V1',ds,seed,h))
       if len(ix)>QUOTA:
        take=np.argpartition(scores,QUOTA-1)[:QUOTA];ix=ix[take];scores=scores[take]
       new=chunk.iloc[ix][features].copy();new.insert(0,'row_id',rowids[ix]);new['Label']=label;new['block_id_ms']=int(b);new['_priority']=scores
       buffers[k]=retain(buffers.get(k),new)
   offset+=len(chunk)
   if ci%10==0:print(ds,f'{offset:,}','raw rows sampled',flush=True)
 if offset!=raw['raw_rows'] or dict(rawcounts)!=raw['raw_class_counts']:raise ValueError('Raw inventory differs')
 for (seed,h,b),exp in expected.items():
  if (remaining[seed,h,b,0],remaining[seed,h,b,1])!=exp[:2]:raise ValueError('Raw post-exclusion counts differ from audit')
 files=[];summary=[]
 for seed in SEEDS:
  oldenv=historical[seed];oldkeys=np.unique(keys(oldenv,features));oldids=oldenv.row_id.to_numpy(np.int64)
  for h in HOURS:
   pieces=[v for (s,hh,b,l),v in buffers.items() if s==seed and hh==h]
   if not pieces or any(len(p)!=QUOTA for p in pieces):raise ValueError('Incomplete quota')
   f=pd.concat(pieces,ignore_index=True).drop(columns='_priority').sort_values(['block_id_ms','Label','row_id']).reset_index(drop=True)
   if not f.row_id.is_unique or np.isin(keys(f,features),source[seed]).any():raise ValueError('Duplicate row IDs/source overlap')
   counts=f.groupby(['block_id_ms','Label']).size()
   if not counts.eq(QUOTA).all() or len(counts)//2<2:raise ValueError('Invalid group class quotas')
   signatures=keys(f,features);_,inv=np.unique(signatures,return_inverse=True)
   crossing=pd.DataFrame({'signature':inv,'block':f.block_id_ms}).groupby('signature').block.nunique()
   rel=f'samples/{ds}/seed_{seed}/{h}h.parquet';(w.local/rel).parent.mkdir(parents=True,exist_ok=True);f.to_parquet(w.local/rel,index=False);files.append(rel)
   summary.append({'dataset':ds,'seed':seed,'hours':h,'rows':len(f),'groups':len(counts)//2,'historical_environment_row_overlap':int(np.isin(f.row_id,oldids).sum()),'historical_environment_signature_overlap':int(np.isin(signatures,oldkeys).sum()),'signatures_in_multiple_actual_windows':int((crossing>1).sum()),'source_signature_overlap':0})
 rel=f'samples/{ds}/sampling_summary.csv';pd.DataFrame(summary).to_csv(w.local/rel,index=False);files.append(rel)
 result={'dataset':ds,'raw_rows':offset,'class_counts':dict(rawcounts),'summaries':summary}
 w.finish(marker,files,result);return result

def paired(vectors):
 ranks=[pd.Series(-np.asarray(v)).rank(method='average').to_numpy() for v in vectors];values=[];undefined=0
 for a,b in itertools.combinations(ranks,2):
  if np.std(a)==0 or np.std(b)==0:values.append(0.);undefined+=1
  else:values.append(float(np.corrcoef(a,b)[0,1]))
 if not values:raise ValueError('Fewer than two groups')
 return float(np.mean(values)),undefined,len(values)
def grouping(f,ds,seed,h):
 starts=np.sort(f.block_id_ms.unique());actual=np.searchsorted(starts,f.block_id_ms.to_numpy());pseudo=np.full(len(f),-1,int);y=f.Label.to_numpy(np.int8)
 rng=np.random.default_rng(state('FRESH_TEMPORAL_V1',ds,seed,h,'pseudo'))
 for lab in [0,1]:
  positions=rng.permutation(np.flatnonzero(y==lab));offset=0
  for k in range(len(starts)):
   n=int(((actual==k)&(y==lab)).sum());pseudo[positions[offset:offset+n]]=k;offset+=n
  assert offset==len(positions)
 for k in range(len(starts)):assert np.array_equal(np.bincount(y[actual==k],minlength=2),np.bincount(y[pseudo==k],minlength=2))
 assert (pseudo>=0).all()
 return starts,actual,pseudo
def fixed_score(th):
 def score(est,x,y):return balanced_accuracy_score(y,(est.predict_proba(x)[:,1]>=th).astype(np.int8))
 return score

class FreshWorkspace(Workspace):
 def finish(self,rel,files,details):
  record={'identity':self.identity,'outputs':{n:sha(self.local/n) for n in files},'details':details,'details_sha256':hashlib.sha256(json.dumps(details,sort_keys=True,allow_nan=False).encode()).hexdigest()}
  write(self.local/rel,record)
  for n in files:self.upload(n)
  self.upload(rel)
 def cached(self,rel):
  details=super().cached(rel)
  if details is not None:
   rec=js(self.local/rel)
   if rec.get('details_sha256')!=hashlib.sha256(json.dumps(details,sort_keys=True,allow_nan=False).encode()).hexdigest():raise ValueError('Checkpoint details checksum differs')
  return details

def run_fresh(root,source):
 w=FreshWorkspace(root,FRESH_STAGE,FRESH_PLAN,source);report={'status':'RUNNING','started_utc':datetime.now(timezone.utc).isoformat(),'completed_group_references':0,'fresh_sampling_experiment_completed':False};units=[];sampling=[]
 try:
  w.setup();features=js(w.stage('Paper3_Materialized/feature_schema_v1.json'))['predictors_in_order']
  if len(features)!=49:raise ValueError('Expected49features')
  for ds in DATASETS:
   result=fresh_sample(w,ds,features);sampling+=result['summaries']
   for seed in SEEDS:
    base=f'Paper3_Source_Models/{ds}/seed_{seed}';prep=joblib.load(w.stage(base+'/source_preprocessor.joblib'))
    if list(prep['features'])!=features:raise ValueError('Preprocessor features differ')
    test=pd.read_parquet(w.stage(f'Paper3_Sanitized/{ds}/seed_{seed}/source_test.parquet'))
    for name in MODELS:
     model=joblib.load(w.stage(base+f'/{name}_model.joblib'))
     if list(model['features'])!=features or model['dataset']!=ds or int(model['seed'])!=seed or model['model_name']!=name or bool(model['uses_standard_scaler'])!=(name=='LogisticRegression'):raise ValueError('Detector identity differs')
     th=float(model['threshold']);est=model['model']
     def transform(f):
      x=prep['imputer'].transform(clean(f,features)).astype(np.float32)
      if model['uses_standard_scaler']:x=prep['logistic_regression_scaler'].transform(x).astype(np.float32)
      if x.shape[1]!=49 or not np.isfinite(x).all():raise ValueError('Invalid transformed data')
      return x
     replay=f'replays/{ds}/seed_{seed}/{name}.json'
     if w.cached(replay) is None:
      saved=pd.read_parquet(w.stage(base+f'/{name}_source_test_predictions.parquet')).set_index('row_id').loc[test.row_id]
      p=est.predict_proba(transform(test))[:,1];diff=float(np.max(abs(p-saved.probability_attack.to_numpy())))
      if diff>1e-7 or not np.array_equal(saved.y_true,test.Label) or not np.array_equal((p>=th).astype(np.int8),saved.y_pred):raise ValueError('Original source replay differs')
      w.finish(replay,[],{'maximum_probability_difference':diff,'source_decisions_identical':True})
     for h in HOURS:
      f=pd.read_parquet(w.restore(f'samples/{ds}/seed_{seed}/{h}h.parquet'));x=transform(f);y=f.Label.to_numpy(np.int8);starts,actual,pseudo=grouping(f,ds,seed,h);stability={};undefined={};pairs={}
      for kind,codes in [('environmental',actual),('sampling',pseudo)]:
       vectors=[]
       for code,start in enumerate(starts):
        ix=np.flatnonzero(codes==code);rowhash=hashlib.sha256(f.row_id.to_numpy('<i8')[ix].tobytes()).hexdigest();marker=f'importance/{ds}/seed_{seed}/{name}/{h}h/{kind}_{code}.json';got=w.cached(marker)
        if got is None:
         print('START',report['completed_group_references'],ds,seed,name,f'{h}h',kind,code+1,'/',len(starts),flush=True);begin=time.monotonic()
         pfi=permutation_importance(est,x[ix],y[ix],scoring=fixed_score(th),n_repeats=3,random_state=state('FRESH_TEMPORAL_V1',ds,seed,h,name,kind,rowhash,'PFI'),n_jobs=1)
         got={'row_ids_sha256':rowhash,'rows':len(ix),'benign':int((y[ix]==0).sum()),'attack':int((y[ix]==1).sum()),'baseline_balanced_accuracy':float(fixed_score(th)(est,x[ix],y[ix])),'importance_repeats':pfi.importances.tolist(),'elapsed_seconds':time.monotonic()-begin}
         w.finish(marker,[],got)
        if got['row_ids_sha256']!=rowhash or got['rows']!=4000 or got['benign']!=QUOTA or got['attack']!=QUOTA:raise ValueError('Importance membership/quota differs')
        v=np.asarray(got['importance_repeats']);assert v.shape==(49,3) and np.isfinite(v).all();vectors.append(v.mean(axis=1));report['completed_group_references']+=1
        write(w.local/'progress.json',report);print('DONE',report['completed_group_references'],'group references',flush=True)
       stability[kind],undefined[kind],pairs[kind]=paired(vectors)
      units.append({'source_dataset':ds,'seed':seed,'model':name,'hours':h,'sampling_instability':1-stability['sampling'],'environmental_instability':1-stability['environmental'],'sampling_environment_gap':stability['sampling']-stability['environmental'],'groups':len(starts),'undefined_sampling_pairs':undefined['sampling'],'undefined_environmental_pairs':undefined['environmental'],'pairs_per_type':pairs['sampling']})
      del f,x;gc.collect()
    del prep,test;gc.collect()
  if len(units)!=len(DATASETS)*len(SEEDS)*len(MODELS)*len(HOURS) or len(sampling)!=len(DATASETS)*len(SEEDS)*len(HOURS) or report['completed_group_references']!=sum(r['groups'] for r in sampling)*len(MODELS)*2:raise ValueError('Incomplete fresh grid')
  frame=pd.DataFrame(units);frame.to_csv(w.local/'fresh_warning_scores_240.csv',index=False);pd.DataFrame(sampling).to_csv(w.local/'sampling_summary_80.csv',index=False)
  write(w.local/'source_score_record.json',{'sha256':sha(w.local/'fresh_warning_scores_240.csv'),'saved_before_new_regressions':True,'post_hoc_prior_outcomes_known':True})
  for rel in ['fresh_warning_scores_240.csv','sampling_summary_80.csv','source_score_record.json']:w.upload(rel)
  totalfits=0;totalpredictions=0
  for label,records in OUTCOME_RECORDS.items():
   for h in HOURS:
    controls=frame[frame.hours==h];inp=pd.DataFrame(records).drop(columns=WARN).merge(controls[KEY+WARN],on=KEY,validate='many_to_one');out=w.local/f'analysis_{label}/{h}h';checks,sc=analyse(inp,out)
    totalfits+=checks['fits'];totalpredictions+=checks['predictions']
    for p in out.rglob('*'):
     if p.is_file():w.upload(str(p.relative_to(w.local)))
  report.update(status='PASS',warning_units=len(units),sampling_combinations=len(sampling),source_replays=len(DATASETS)*len(SEEDS)*len(MODELS),regression_fits=totalfits,regression_predictions=totalpredictions,fresh_sampling_experiment_completed=True,completed_utc=datetime.now(timezone.utc).isoformat())
 except Exception as e:report.update(status='INCOMPLETE',error_type=type(e).__name__,error=str(e));print('STOPPED',type(e).__name__,str(e),flush=True)
 return w.package(report)
