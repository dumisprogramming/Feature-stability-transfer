"""Read-only exact-pattern family provenance audit of the pinned original captures."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter,defaultdict
from itertools import combinations
import hashlib,json,zipfile,time,shutil,re,traceback,platform,io,csv
import numpy as np,pandas as pd

KNOWN={'Benign','Bot','FTP-BruteForce','SSH-Bruteforce','DoS attacks-GoldenEye','DoS attacks-Slowloris','DoS attacks-SlowHTTPTest','DoS attacks-Hulk','DDOS attack-LOIC-UDP','DDOS attack-HOIC','DDoS attacks-LOIC-HTTP','Brute Force -Web','Brute Force -XSS','SQL Injection','Infilteration','Infiltration'}

TARGET_LABELS={'BENIGN','DDoS','PortScan','Bot','Infiltration','Web Attack � Brute Force','Web Attack � XSS','Web Attack � Sql Injection','FTP-Patator','SSH-Patator','DoS slowloris','DoS Hulk','DoS Slowhttptest','DoS GoldenEye','Heartbleed'}

def timestamps(v):
 ans=pd.Series(pd.NaT,index=v.index,dtype='datetime64[ns]')
 for fmt in ['%d/%m/%Y %H:%M:%S','%d/%m/%Y %H:%M:%S.%f','%d/%m/%Y %I:%M:%S %p']:
  remaining=ans.isna();ans.loc[remaining]=pd.to_datetime(v.loc[remaining],format=fmt,errors='coerce')
 return ans

def cleaned(frame,cols,source=False,date=None):
 label=frame['Label'].str.strip();repeated=label.eq('Label');allowed=label.isin(KNOWN if source else TARGET_LABELS)
 unknown=label[~allowed&~repeated].value_counts().to_dict()
 if unknown:raise ValueError('Unrecognised supplied labels: '+str(unknown))
 x=frame[cols].apply(pd.to_numeric,errors='coerce').to_numpy(np.float64)
 finite=np.isfinite(x);valid=finite.all(axis=1)&(x>=0).all(axis=1)&(x==np.floor(x)).all(axis=1)&(x[:,0]<=65535)&allowed.to_numpy()
 if np.any(finite&(x>2**53-1)):raise ValueError('Integer exceeds exact float64 range; stop before signature conversion')
 if source:
  ts=timestamps(frame['Timestamp'].str.strip());ok=ts.dt.strftime('%Y-%m-%d').eq(date);valid&=ok.to_numpy();blocks=ts.dt.floor('6h').dt.strftime('%Y-%m-%d %H:%M:%S').to_numpy()
 else:blocks=np.full(len(frame),'',dtype=object)
 pos=np.flatnonzero(valid);values=x[pos].astype('<i8');values[values==0]=0
 keys=np.ascontiguousarray(values).view(np.dtype((np.void,48))).ravel()
 y=label.iloc[pos].ne('Benign' if source else 'BENIGN').to_numpy(np.int8)
 return keys,y,blocks[pos],pos,label.iloc[pos].to_numpy(),{'input_rows':len(frame),'repeated_headers':int(repeated.sum()),'retained_rows':len(pos),'retained_benign':int((y==0).sum()),'retained_attack':int((y==1).sum()),'excluded_rows':int((~valid).sum())}

STAGE='supplementary_family_label_provenance_20261026'
PARENT='supplementary_common_representation_partition_20261026'
FEATURES=['destination_port','duration_us','fwd_packets','bwd_packets','fwd_packet_bytes','bwd_packet_bytes']
SOURCE_COLS=['Dst Port','Flow Duration','Tot Fwd Pkts','Tot Bwd Pkts','TotLen Fwd Pkts','TotLen Bwd Pkts']
TARGET_COLS=['Destination Port','Flow Duration','Total Fwd Packets','Total Backward Packets','Total Length of Fwd Packets','Total Length of Bwd Packets']
ROLES=['train','calibration','source_test','environment','target']
CHUNK_SIZE=100000

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
 return h.hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,allow_nan=False).encode()).hexdigest()
def write(path,x):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n');tmp.replace(path)
def read(path):return json.loads(Path(path).read_text())
def norm(s):return ''.join(c for c in str(s).casefold() if c.isalnum())
def matches(label,aliases):return norm(label) in {norm(a) for a in aliases}
def signature(x):
 if x.dtype!=np.float64 or x.ndim!=2 or x.shape[1]!=6 or not np.isfinite(x).all() or (x<0).any() or (x>2**53-1).any() or (x!=np.floor(x)).any() or (x[:,0]>65535).any():raise ValueError('Invalid pinned float64/six-integer panel')
 return np.ascontiguousarray(x.astype('<i8')).view('V48').ravel()
class HashingReader(io.RawIOBase):
 def __init__(self,raw):super().__init__();self.raw=raw;self.hasher=hashlib.sha256();self.bytes=0
 def readable(self):return True
 def readinto(self,b):
  chunk=self.raw.read(len(b));n=len(chunk)
  if n:b[:n]=chunk;self.hasher.update(chunk);self.bytes+=n
  return n

class Workspace:
 def __init__(self,root,context,code,plan,local_base):
  self.root=Path(root);self.parent=self.root/'Paper3_DataSet'/PARENT;self.local=Path(local_base)/STAGE/'run_v1';self.remote=self.root/'Paper3_DataSet'/STAGE/'run_v1';self.local.mkdir(parents=True,exist_ok=True);self.remote.mkdir(parents=True,exist_ok=True)
  self.identity={'code_sha256':hashlib.sha256(code.encode()).hexdigest(),'plan_sha256':hashlib.sha256(plan.encode()).hexdigest(),'context_sha256':digest(context),'software':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__},'chunk_size':CHUNK_SIZE,'no_model_fitting':True}
  if (self.remote/'identity.json').exists() and read(self.remote/'identity.json')!=self.identity:raise ValueError('Resume identity differs; keep existing stage unchanged and report the mismatch')
  write(self.local/'identity.json',self.identity);write(self.local/'context.json',context);(self.local/'CODE.py').write_text(code);(self.local/'PLAN.md').write_text(plan)
  for n in ['identity.json','context.json','CODE.py','PLAN.md']:self.upload(n)
 def upload(self,n):
  src=self.local/n;dst=self.remote/n;dst.parent.mkdir(parents=True,exist_ok=True);tmp=dst.with_suffix(dst.suffix+'.tmp');shutil.copyfile(src,tmp)
  if sha(tmp)!=sha(src):raise ValueError('Drive output copy mismatch')
  tmp.replace(dst)
 def finish(self,marker,outputs,details):
  rec={'identity':self.identity,'details':details,'details_sha256':digest(details),'outputs':{n:sha(self.local/n) for n in outputs}};write(self.local/marker,rec)
  for n in outputs:self.upload(n)
  self.upload(marker)
 def cached(self,marker):
  if not (self.remote/marker).exists():return None
  rec=read(self.remote/marker)
  if rec['identity']!=self.identity or digest(rec['details'])!=rec['details_sha256']:raise ValueError('Checkpoint identity/details mismatch')
  for n,h in rec['outputs'].items():
   src=self.remote/n
   if sha(src)!=h:raise ValueError('Changed checkpoint output: '+n)
   dst=self.local/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
  shutil.copyfile(self.remote/marker,self.local/marker);return rec['details']
 def report(self,summary):
  write(self.local/'summary.json',summary)
  try:self.upload('summary.json')
  except OSError as e:print('Drive summary unavailable; local copy retained:',e)
  files=[p for p in sorted(self.local.rglob('*')) if p.is_file() and 'input_cache' not in p.parts and p.suffix in ['.json','.md','.py','.txt'] and p.name!='SHA256SUMS.json'];write(self.local/'SHA256SUMS.json',{str(p.relative_to(self.local)):sha(p) for p in files});stamp=datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f');archive=self.local.parent/f'family_provenance_report_{stamp}.zip'
  with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
   for p in files+[self.local/'SHA256SUMS.json']:z.write(p,p.relative_to(self.local))
  try:
   dest=self.remote.parent/archive.name;tmp=dest.with_suffix('.zip.tmp');shutil.copyfile(archive,tmp)
   if sha(tmp)!=sha(archive):raise ValueError('Report ZIP copy mismatch')
   tmp.replace(dest);print('Drive report:',dest,flush=True)
  except OSError as e:print('Download local report now; Drive report unavailable:',e)
  return archive

def selected_index(w,context):
 m=context['manifest'];parent=w.parent
 if sha(parent/'panel_manifest.json')!=context['manifest_sha256'] or sha(parent/'identity.json')!=context['parent_identity_sha256'] or read(parent/'panel_manifest.json')!=m or m['features']!=FEATURES:raise ValueError('Pinned parent identity/manifest changed')
 records=[];key_arrays=[];source_locations=set()
 cache=w.local/'input_cache';cache.mkdir(exist_ok=True)
 for role in ROLES:
  src=parent/'panels'/f'{role}.npz';dest=cache/src.name
  if not dest.exists() or sha(dest)!=m[role]['sha256']:
   shutil.copyfile(src,dest)
   if sha(dest)!=m[role]['sha256']:raise ValueError('Pinned panel changed: '+role)
  with np.load(dest,allow_pickle=False) as z:d={k:z[k] for k in ['x','y','family','file_index','row_index','block']}
  keys=signature(d['x']);n=len(keys)
  if n!=m[role]['rows'] or len(np.unique(keys))!=n or any(len(v)!=n for v in d.values()):raise ValueError('Panel size/uniqueness mismatch')
  y=d['y'];benign='BENIGN' if role=='target' else 'Benign'
  if not np.isin(y,[0,1]).all() or not np.array_equal(d['family']==benign,y==0) or any(int((y==k).sum())!=m[role]['benign' if k==0 else 'attack'] for k in [0,1]):raise ValueError('Panel labels differ')
  if role!='target':
   ids=set(zip(map(int,d['file_index']),map(int,d['row_index'])))
   if len(ids)!=n or ids&source_locations:raise ValueError('Source row locations overlap')
   source_locations.update(ids)
  key_arrays.append(keys)
  for i in range(n):records.append({'role':role,'panel_row':i,'binary_label':int(y[i]),'representative_family':str(d['family'][i]),'file_index':int(d['file_index'][i]),'row_index':int(d['row_index'][i]),'block':str(d['block'][i])})
 allkeys=np.concatenate(key_arrays);order=np.argsort(allkeys);keys=allkeys[order]
 if len(np.unique(keys))!=len(keys):raise ValueError('Selected panel signatures overlap')
 meta=[]
 for i,j in enumerate(order):
  rec=records[int(j)];meta.append({'pattern_id':i,'signature_sha256':hashlib.sha256(bytes(keys[i])).hexdigest(),**rec})
 write(w.local/'selected_pattern_index.json',meta);w.upload('selected_pattern_index.json');return keys,meta

def required_header(stream,wanted):
 header=next(csv.reader(stream));trim=[s.strip() for s in header]
 if any(trim.count(s)!=1 for s in wanted):raise ValueError('Required header absent or duplicated')
 return [s for s in header if s.strip() in wanted]

def scan_stream(stream,usecols,source,expected_date,keys,meta,file_index,label):
 counts=Counter();occ=Counter();first={};hits=set();offset=0;cols=SOURCE_COLS if source else TARGET_COLS;expected=[m for m in meta if (m['role']!='target')==source and m['file_index']==file_index]
 for frame in pd.read_csv(stream,usecols=usecols,dtype=str,keep_default_na=False,chunksize=CHUNK_SIZE,encoding='utf-8-sig',on_bad_lines='error'):
  frame.columns=[v.strip() for v in frame.columns];kk,y,blocks,pos,families,c=cleaned(frame,cols,source,expected_date);counts.update(c)
  indexes=np.searchsorted(keys,kk);ok=indexes<len(keys);locations=np.flatnonzero(ok);ok[locations]&=(keys[indexes[locations]]==kk[locations]);take=np.flatnonzero(ok)
  if len(take):
   df=pd.DataFrame({'pattern_id':indexes[take],'family':families[take],'row_index':pos[take]+offset})
   for (pid,family),g in df.groupby(['pattern_id','family'],sort=False):
    k=(int(pid),str(family));occ[k]+=len(g);row=int(g['row_index'].min());first[k]=min(first.get(k,row),row)
  # Independently locate every saved representative at its original raw row.
  for saved in expected:
   raw_row=saved['row_index']
   if offset<=raw_row<offset+len(frame):
    j=int(np.searchsorted(pos,raw_row-offset));pid=saved['pattern_id']
    if j>=len(pos) or int(pos[j])!=raw_row-offset or kk[j]!=keys[pid] or str(families[j])!=saved['representative_family'] or int(y[j])!=saved['binary_label']:raise ValueError('Saved representative does not replay at original row: '+str(pid))
    if source and str(blocks[j])!=saved['block']:raise ValueError('Saved source representative time block differs: '+str(pid))
    hits.add(pid)
  offset+=len(frame)
  if offset%(5*CHUNK_SIZE)==0:print(label,'rows scanned',offset,'matching pattern/family entries',len(occ),flush=True)
 if hits!={r['pattern_id'] for r in expected}:raise ValueError('Not every saved representative was found in '+label)
 records=[{'pattern_id':pid,'family':family,'occurrences':int(n),'first_row_index':first[(pid,family)]} for (pid,family),n in sorted(occ.items())]
 return {'file_index':file_index,'counts':dict(counts),'occurrences':records,'representative_row_hits':sorted(hits)}

def aggregate(meta,source_records,target_records,candidates):
 maps={'source':defaultdict(Counter),'target':defaultdict(Counter)};first={'source':{},'target':{}}
 for side,records in [('source',source_records),('target',target_records)]:
  for rec in records:
   fi=rec['file_index']
   for r in rec['occurrences']:
    pid=r['pattern_id'];label=r['family'];maps[side][pid][label]+=r['occurrences'];where=(fi,r['first_row_index']);first[side][pid]=min(first[side].get(pid,where),where)
 per_pattern=[];by_role={}
 for m in meta:
  pid=m['pattern_id'];side='target' if m['role']=='target' else 'source';labels=maps[side][pid]
  if not labels or labels[m['representative_family']]<1 or first[side][pid]!=(m['file_index'],m['row_index']):raise ValueError('First representative does not match full raw traversal')
  own={str(k):int(v) for k,v in sorted(labels.items())};binary={int(label!=('BENIGN' if side=='target' else 'Benign')) for label in labels}
  per_pattern.append({'pattern_id':pid,'role':m['role'],'representative_family':m['representative_family'],'raw_own_family_counts':own,'mixed_exact_families':len(labels)>1,'binary_conflict':len(binary)>1,'cross_capture_family_counts':dict(sorted(maps['source' if side=='target' else 'target'][pid].items()))})
 for role in ROLES:
  rows=[r for r in per_pattern if r['role']==role];by_role[role]={'selected_signatures':len(rows),'mixed_exact_family_signatures':sum(r['mixed_exact_families'] for r in rows),'binary_conflict_signatures':sum(r['binary_conflict'] for r in rows),'raw_own_occurrences':sum(sum(r['raw_own_family_counts'].values()) for r in rows),'signatures_also_present_in_other_capture':sum(bool(r['cross_capture_family_counts']) for r in rows)}
 family=[]
 for c in candidates:
  name=c['candidate_tool_label_family'];rr=[]
  for role in ROLES:
   side='target' if role=='target' else 'source';aliases=c['aliases'][side];rows=[r for r in per_pattern if r['role']==role];declared=[r for r in rows if matches(r['representative_family'],aliases)];retained=[r for r in rows if not matches(r['representative_family'],aliases)]
   candidate_count=lambda r:sum(n for label,n in r['raw_own_family_counts'].items() if matches(label,aliases))
   mixed=[r for r in declared if any(not matches(label,aliases) for label in r['raw_own_family_counts'])];hidden=[r for r in retained if candidate_count(r)>0]
   rr.append({'role':role,'declared_family_signatures':len(declared),'declared_family_signatures_with_other_family_labels':len(mixed),'raw_candidate_occurrences_in_declared_signatures':sum(candidate_count(r) for r in declared),'raw_other_family_occurrences_in_declared_signatures':sum(sum(r['raw_own_family_counts'].values())-candidate_count(r) for r in declared),'retained_other_representative_signatures_with_candidate_occurrences':len(hidden),'raw_candidate_occurrences_hidden_in_retained_signatures':sum(candidate_count(r) for r in hidden)})
  own_selected=[r for r in rr if r['role'] in ['train','calibration']];family.append({'candidate':name,'by_role':rr,'retained_training_calibration_signatures_with_raw_candidate_occurrences':sum(r['retained_other_representative_signatures_with_candidate_occurrences'] for r in own_selected),'raw_candidate_occurrences_in_retained_training_calibration_patterns':sum(r['raw_candidate_occurrences_hidden_in_retained_signatures'] for r in own_selected),'semantic_equivalence_established':False})
 return {'by_role':by_role,'candidate_families':family,'all_selected_patterns_first_representative_replayed':True,'source_raw_files_completed':len(source_records),'target_raw_members_completed':len(target_records),'selected_pattern_records':len(per_pattern),'no_model_fitting':True,'semantic_equivalence_established':False,'production_validation_completed':False},per_pattern

def run(root,context,code,plan,local_base=Path('/content')):
 w=Workspace(root,context,code,plan,local_base);(w.local/'error.txt').unlink(missing_ok=True);start=time.monotonic();summary={'status':'RUNNING','no_model_fitting':True,'prior_outcomes_known':True,'new_source_files_this_session':0,'new_target_members_this_session':0,'raw_occurrence_provenance_only':True}
 try:
  required={'manifest','manifest_sha256','parent_identity_sha256','raw_sources','target_relative_path','target_archive_sha256','target_members','target_counts','selected_candidates'}
  if not required.issubset(context):raise ValueError('Missing fixed audit context fields: '+str(sorted(required-set(context))))
  if len(context['target_members'])!=len(context['target_counts']):raise ValueError('Target member/count context lengths differ')
  if context['manifest'].get('target_archive_sha256',context['target_archive_sha256'])!=context['target_archive_sha256']:raise ValueError('Target archive pins disagree')
  keys,meta=selected_index(w,context);sources=[]
  for fi,c in enumerate(context['raw_sources']):
   rel=f'source_{fi:02d}.json';marker=rel.replace('.json','.complete.json');path=w.root/c['relative_path'];st=path.stat();old=w.cached(marker)
   if old is not None:
    if old['input_sha256']!=c['sha256'] or old['input_size_bytes']!=st.st_size or old['input_mtime_ns']!=st.st_mtime_ns:raise ValueError('Completed raw source metadata/pin changed; do not silently reuse')
    sources.append(old);print('Reused completed source',fi+1,'/',len(context['raw_sources']),flush=True);continue
   if st.st_size!=c['size_bytes']:raise ValueError('Raw source size changed')
   with path.open('r',encoding='utf-8-sig',newline='') as f:use=required_header(f,SOURCE_COLS+['Timestamp','Label'])
   date=datetime.strptime(re.search(r'\d{2}-\d{2}-\d{4}',path.name).group(),'%d-%m-%Y').strftime('%Y-%m-%d')
   print('Scanning source',fi+1,'/',len(context['raw_sources']),path.name,flush=True)
   with path.open('rb') as raw:
    hasher=HashingReader(raw)
    with io.BufferedReader(hasher) as stream:
     rec=scan_stream(stream,use,True,date,keys,meta,fi,'Source '+str(fi+1))
     while stream.read(2**20):pass
     actual_hash=hasher.hasher.hexdigest();actual_bytes=hasher.bytes
   if actual_hash!=c['sha256'] or actual_bytes!=c['size_bytes']:raise ValueError('Raw source hash differs from parent preflight')
   if (path.stat().st_size,path.stat().st_mtime_ns)!=(st.st_size,st.st_mtime_ns):raise ValueError('Raw source changed during scan')
   cnt=rec['counts']
   if cnt['input_rows']!=c['expected_rows'] or cnt['retained_benign']!=c['expected_valid_benign'] or cnt['retained_attack']!=c['expected_valid_attack']:raise ValueError('Valid raw source counts differ from original partition')
   rec.update(input_sha256=actual_hash,input_size_bytes=actual_bytes,input_mtime_ns=st.st_mtime_ns,relative_path=c['relative_path']);write(w.local/rel,rec);w.finish(marker,[rel],rec);sources.append(rec);summary['new_source_files_this_session']+=1
  cache=w.local/'input_cache';archive=w.root/context['target_relative_path'];dest=cache/'MachineLearningCSV.zip'
  if not dest.exists() or sha(dest)!=context['target_archive_sha256']:
   print('Copying and verifying target archive once',flush=True);shutil.copyfile(archive,dest)
   if sha(dest)!=context['target_archive_sha256']:raise ValueError('Pinned target archive hash differs')
  targets=[]
  with zipfile.ZipFile(dest) as z:
   names=sorted(n for n in z.namelist() if n.lower().endswith('.csv'))
   if names!=context['target_members']:raise ValueError('Target member names differ from original partition')
   for fi,name in enumerate(names):
    rel=f'target_{fi:02d}.json';marker=rel.replace('.json','.complete.json');rec=w.cached(marker)
    if rec is not None:
     if rec['archive_sha256']!=context['target_archive_sha256'] or rec['member']!=name:raise ValueError('Target checkpoint identity changed')
     targets.append(rec);print('Reused completed target member',fi+1,'/',len(names),flush=True);continue
    with z.open(name) as raw:
     with io.TextIOWrapper(raw,encoding='utf-8-sig',newline='') as f:use=required_header(f,TARGET_COLS+['Label'])
    print('Scanning target member',fi+1,'/',len(names),name,flush=True)
    with z.open(name) as stream:rec=scan_stream(stream,use,False,None,keys,meta,fi,'Target '+str(fi+1))
    expected=context['target_counts'][fi]
    if rec['counts']!=expected:raise ValueError('Target filtering counts differ from original partition')
    rec.update(archive_sha256=context['target_archive_sha256'],member=name);write(w.local/rel,rec);w.finish(marker,[rel],rec);targets.append(rec);summary['new_target_members_this_session']+=1
  final,per_pattern=aggregate(meta,sources,targets,context['selected_candidates']);write(w.local/'pattern_provenance.json',per_pattern);write(w.local/'family_provenance_summary.json',final)
  text=['# Raw occurrence family provenance audit','','Completed selected-pattern scan; completion does not imply pure families or equivalent attack semantics.','','| Candidate | Retained training/calibration patterns with candidate raw labels | Candidate raw occurrences in those retained patterns |','|---|---:|---:|']
  for r in final['candidate_families']:text.append(f"| {r['candidate']} | {r['retained_training_calibration_signatures_with_raw_candidate_occurrences']} | {r['raw_candidate_occurrences_in_retained_training_calibration_patterns']} |")
  text+=['','The audit changes no panels, models, predictions or prior results. If retained fitting patterns carry excluded-family raw labels, S17 remains an ablation of first-representative labels. A pure-pattern sensitivity run would require a new plan and new fits; it must not replace the original result silently. Raw label consistency does not certify generator settings, label correctness, independent warning utility or production prevalence.']
  (w.local/'AUDIT.md').write_text('\n'.join(text)+'\n');w.finish('audit.complete.json',['pattern_provenance.json','family_provenance_summary.json','AUDIT.md','selected_pattern_index.json'],final);summary.update(status='FAMILY_PROVENANCE_AUDIT_COMPLETE',source_files_completed=len(sources),target_members_completed=len(targets),selected_patterns=len(meta),raw_source_rows=sum(r['counts']['input_rows'] for r in sources),raw_target_rows=sum(r['counts']['input_rows'] for r in targets))
 except Exception as e:
  summary.update(status='FAMILY_PROVENANCE_AUDIT_BLOCKED_RESUMABLE',error=str(e));(w.local/'error.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
  try:w.upload('error.txt')
  except OSError:pass
 summary['session_elapsed_seconds']=time.monotonic()-start;print(json.dumps(summary,indent=2),flush=True);return w.report(summary)
