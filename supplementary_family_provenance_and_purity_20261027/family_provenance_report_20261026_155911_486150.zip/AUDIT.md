# Raw occurrence family provenance audit

Completed selected-pattern scan; completion does not imply pure families or equivalent attack semantics.

| Candidate | Retained training/calibration patterns with candidate raw labels | Candidate raw occurrences in those retained patterns |
|---|---:|---:|
| GoldenEye | 1 | 1 |
| Hulk | 0 | 0 |
| SSH Patator | 1 | 3 |

The audit changes no panels, models, predictions or prior results. If retained fitting patterns carry excluded-family raw labels, S17 remains an ablation of first-representative labels. A pure-pattern sensitivity run would require a new plan and new fits; it must not replace the original result silently. Raw label consistency does not certify generator settings, label correctness, independent warning utility or production prevalence.
