# Read only raw occurrence family provenance audit

Prepared 26 October 2026 after S16, S17 and their support audit outcomes were known. This is a data-provenance audit, not a detector experiment. No source or target outcome is optimized, and no original panel, model, prediction, protocol or result is changed.

## Purpose

Check whether first-representative family labels in the six-field panels conceal other family labels among raw occurrences with the exact same predictor signature. In particular, determine whether removing GoldenEye, Hulk or SSH Patator representatives still leaves training/calibration patterns that occur with that family's raw label. This can qualify the interpretation of S17's representative-label ablation. It cannot certify correctness of raw labels, equivalent attack-generation settings, a common fine-family taxonomy, absence of related mechanisms or predictive warning utility.

## Fixed universe and raw filters

Use the five unchanged pinned panels: 20,000 training, 4,000 calibration, 4,000 source-test, 9,000 environmental and 80,000 target representatives, totalling 117,000 disjoint signatures. The monitored universe is their union. For every signature, collect matching eligible raw occurrences separately in both captures, even if the pattern belongs to a panel from the other capture. Cross-capture matches are diagnostics; they do not change the S16/S17 target exclusions or fitting rows.

Scan all ten pinned CSE-CIC-IDS2018 CSVs and the eight original CICIDS2017 ZIP CSV members, in the original order. No new download, live capture or surrogate dataset is introduced. Apply the exact `cleaned` and `timestamps` function bodies copied from the executed parent partition code. Known labels, repeated-header handling, finite/nonnegative/integer-valued features, port bounds, exact float64 range, source date matching, six-hour block formatting and target replacement characters remain unchanged. The universe is eligible raw occurrences under these original filters, not every unfiltered line. Invalid rows remain excluded and their counts are reported.

The ordered features remain destination port, duration in microseconds, forward/backward packet counts and forward/backward bytes. Accepted float64 integers map bijectively to an exact 48-byte little-endian int64 signature. No float32 conversion, feature rounding or fuzzy matching is used. Check all panel hashes, the parent identity and manifest, uniqueness, binary/family consistency, source location separation and cross-panel signature separation before scanning.

## Streaming and integrity

Read source CSVs directly from Drive in chunks of 100,000 rows using only the six predictors, Timestamp and Label. A hashing binary reader computes the full original source-file SHA-256 during the same parse, avoiding a second complete read. The small header check is separate. Drain the stream and verify byte count and full pinned hash before accepting a completed file. Verify its input-row count and eligible benign/attack counts against the parent preflight. Check size/mtime before and after scanning to detect concurrent changes. No multi-gigabyte source copies or full-capture database are created.

Copy the approximately 235 MB target ZIP to this stage's local cache and verify its pinned full hash before reading its members. On resume, verify the cached ZIP or recopy it. Match the complete ordered member list and each member's original filtering counts. Preserve exact supplied labels, including pre-existing replacement characters.

For each matched pattern/family within a raw file/member, save the occurrence count and first raw row. Independently replay every selected representative at its pinned file index and original data-row index, checking exact predictor signature, binary label and family label. Aggregate first matches over the full ordered capture and require agreement with the selected representative location. These checks establish consistency with the supplied labels and files; they are not independent ground-truth adjudication.

## Recorded findings

For every selected pattern, report its role, representative family, exact own-capture family-count dictionary, mixed-family flag, binary-conflict flag and cross-capture family-count dictionary. A separate selected-pattern index includes panel row, original file/row location and SHA-256 of the six-field key, without raw feature values or IP fields.

For each panel role report number of selected patterns, mixed exact-family patterns, binary-conflict patterns, matching eligible raw occurrences and cross-capture matches. Any measured conflict is a finding to report; audit completion does not assert purity.

For GoldenEye, Hulk and SSH Patator, report by role: declared-family signature count; declared-family signatures also carrying another raw family label; candidate raw occurrences under declared signatures; other-family raw occurrences under those signatures; retained other-representative signatures carrying candidate raw labels; and candidate raw occurrences hidden under those retained signatures. Sum the retained training/calibration diagnostics explicitly. These describe potential contamination of a first-label ablation, not physical training on every matching raw occurrence or a validated semantic exposure measure. Training used only its saved representatives.

Do not silently purify, exclude, relabel or retrain. If mixed/hidden labels are found, retain S17 as reported and evaluate a separately planned pure-pattern sensitivity only if warranted. Even a zero finding cannot certify equivalent generators or absence of all related attacks. This audit does not complete broader capture validation or measured production prevalence.

## Safe checkpoints and resume

Write only to `Paper3_DataSet/supplementary_family_label_provenance_20261026/run_v1/`. Input files and old results are read-only. Checkpoint independently after each complete source file and each complete target member, only after hash/count gates pass. On resume verify code/plan/context/software and checkpoint output hashes. For completed source files, verify stored pinned hash identity plus unchanged current size/mtime; their prior full-content scan is reused rather than rereading all bytes. A mutation preserving size and mtime would not be detected by that metadata-only resume check. The completion record remains evidence of the original pinned-content scan. Do not intentionally edit inputs between runs.

Interrupted partial-file counters are not accepted and the interrupted file/member is reread from the start. Previously completed files are reused. Keep the same notebook unchanged, reconnect and Run all after a disconnect. A version/hash mismatch blocks rather than mixing runs. No dependency installation or model training is performed.

The compact report contains code, plan, context, identities, selected-pattern index, per-file/member occurrence counts, per-pattern provenance, candidate summaries, checkpoint details and hashes. It excludes raw captures, input panel NPZs and cached ZIP bytes. Only `FAMILY_PROVENANCE_AUDIT_COMPLETE` means all monitored files/members were processed; this status does not mean families are pure or semantically equivalent. `FAMILY_PROVENANCE_AUDIT_BLOCKED_RESUMABLE` is a diagnostic report. The real scan has not run during package preparation; synthetic tests use small fixtures and do not establish a runtime estimate for Drive.
